import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Coins, Shield, Sword, Star, Zap, Repeat } from "lucide-react";

const getItemIcon = (type) => {
  switch (type) {
    case "weapon": return Sword;
    case "armor": return Shield;
    case "accessory": return Star;
    case "consumable": return Zap;
    default: return Shield;
  }
};

const getRarityColor = (rarity) => {
  switch (rarity) {
    case "legendary": return "from-yellow-400 to-amber-600 text-black";
    case "epic": return "from-purple-400 to-pink-600 text-white";
    case "rare": return "from-blue-400 to-cyan-600 text-white";
    case "uncommon": return "from-green-400 to-emerald-600 text-white";
    default: return "from-gray-400 to-slate-600 text-white";
  }
};

export default function SellItem({ item, onSell }) {
  const Icon = getItemIcon(item.type);

  return (
    <Card className="fantasy-border bg-stone-800/90 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${getRarityColor(item.rarity)} flex items-center justify-center`}>
              <Icon className="w-6 h-6" />
            </div>
            <div>
              <CardTitle className="text-amber-100 text-lg">{item.name}</CardTitle>
              <Badge variant="outline" className="text-xs border-amber-600/30 text-amber-300">
                {item.rarity} {item.type}
              </Badge>
            </div>
          </div>
          <Badge className="bg-blue-600 text-white">
            Owned: {item.quantity}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <p className="text-amber-300/80 text-sm h-10 overflow-hidden">{item.description}</p>
        
        <Button
            onClick={() => onSell(item)}
            className="w-full bg-gradient-to-r from-red-600 to-orange-700 hover:from-red-700 hover:to-orange-800 text-white font-bold"
        >
            <Repeat className="w-4 h-4 mr-2" />
            Sell for {item.sell_price || 0}
            <Coins className="w-4 h-4 ml-1" />
        </Button>
      </CardContent>
    </Card>
  );
}