
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Coins, Shield, Sword, Star, Zap, Lock } from "lucide-react";

const getItemIcon = (type) => {
  switch (type) {
    case "weapon": return Sword;
    case "armor": return Shield;
    case "accessory": return Star;
    case "consumable": return Zap;
    default: return Shield;
  }
};

const getRarityColor = (rarity) => {
  switch (rarity) {
    case "legendary": return "from-yellow-400 to-amber-600 text-black";
    case "epic": return "from-purple-400 to-pink-600 text-white";
    case "rare": return "from-blue-400 to-cyan-600 text-white";
    case "uncommon": return "from-green-400 to-emerald-600 text-white";
    default: return "from-gray-400 to-slate-600 text-white";
  }
};

const getStatDisplayName = (statKey) => {
  const statNames = {
    strength: "Strength",
    dexterity: "Dexterity", 
    constitution: "Constitution",
    intelligence: "Intelligence",
    wisdom: "Wisdom",
    charisma: "Charisma",
    coin_bonus_percentage: "Coin Bonus"
  };
  // Fallback to title case for other stat keys
  return statNames[statKey] || statKey.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
};

export default function ShopItem({ item, userCoins, onPurchase, userOwns = 0 }) {
  const Icon = getItemIcon(item.type);
  const canAfford = userCoins >= item.price;
  
  // Attempt to parse stat_bonuses if it's a string
  let statBonuses = null;
  if (item.stat_bonuses) {
      if (typeof item.stat_bonuses === 'object') {
          statBonuses = item.stat_bonuses;
      } else if (typeof item.stat_bonuses === 'string') {
          try {
              // Python's dict `str()` uses single quotes, which isn't valid JSON.
              // Replace them to parse correctly.
              statBonuses = JSON.parse(item.stat_bonuses.replace(/'/g, '"'));
          } catch (e) {
              console.error("Could not parse stat_bonuses string:", item.stat_bonuses);
          }
      }
  }

  return (
    <Card className="fantasy-border bg-stone-800/90 backdrop-blur-sm hover:scale-105 transition-all duration-300">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${getRarityColor(item.rarity)} flex items-center justify-center`}>
              <Icon className="w-6 h-6" />
            </div>
            <div>
              <CardTitle className="text-amber-100 text-lg">{item.name}</CardTitle>
              <Badge variant="outline" className="text-xs border-amber-600/30 text-amber-300">
                {item.rarity} {item.type}
              </Badge>
            </div>
          </div>
          {userOwns > 0 && (
            <Badge className="bg-green-600 text-white">
              Owned: {userOwns}
            </Badge>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <p className="text-amber-300/80 text-sm h-10 overflow-hidden">{item.description}</p>
        
        {/* Use the parsed statBonuses object here */}
        {statBonuses && typeof statBonuses === 'object' && Object.keys(statBonuses).length > 0 && (
          <div className="text-xs space-y-1">
            <div className="text-amber-200 font-medium">Bonuses:</div>
            {Object.entries(statBonuses).map(([stat, bonus]) => {
              const bonusValue = Number(bonus);
              return bonusValue > 0 && (
                <div key={stat} className="text-green-400">
                  +{bonusValue}{stat === 'coin_bonus_percentage' ? '%' : ''} {getStatDisplayName(stat)}
                </div>
              );
            })}
          </div>
        )}
        
        <div className="flex items-center justify-between pt-2 border-t border-stone-600/30">
          <div className="flex items-center gap-2">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="font-bold text-amber-100">{item.price || 0} Gold</span>
          </div>
        </div>

        <Button
            onClick={() => onPurchase(item)}
            disabled={!canAfford}
            className={`w-full ${
              canAfford 
                ? 'bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-700 hover:to-yellow-700 text-stone-900'
                : 'bg-gray-600 text-gray-300'
            } font-bold`}
          >
            {!canAfford ? (
              <>
                <Lock className="w-4 h-4 mr-2" />
                Can't Afford
              </>
            ) : (
              <>
                <Coins className="w-4 h-4 mr-2" />
                Buy
              </>
            )}
        </Button>
      </CardContent>
    </Card>
  );
}
