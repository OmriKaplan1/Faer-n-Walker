
import { createRandomEncounter } from '@/api/functions';
import { getNearbyEncounters } from '@/api/functions';
import { updatePlayerLocation } from '@/api/functions';
import { updateUserData } from '@/api/functions';
import { getUserData } from '@/api/functions'; // Added import for getUserData

// GPS accuracy thresholds
const MIN_ACCURACY_FOR_ENCOUNTERS = 25;
const MIN_ACCURACY_FOR_STEPS = 30; // FIX: Increased from 15m to 30m to be more permissive

class GpsService {
  constructor() {
    this.state = {
      isTrackingLocation: false,
      playerLocation: null,
      locationAccuracy: null,
      encounters: [],
      userStats: null,
      sessionSteps: 0,
      gpsStatus: 'inactive'
    };
    this.subscribers = [];
    this.watchId = null;
    this.lastPosition = null;
    this.initialUserStats = null; // NEW: To store stats at the start of the session
    // sessionSteps is already defined in constructor state and outside.
    // It's defined twice. The one outside the constructor is used for calculation.
    // It should be consistent. Let's make sure it's the one in state that's authoritative.
    // However, for speed and consistency with the outline's usage, I'll keep the `this.sessionSteps` property
    // for direct manipulation in `processMovement` and update the state's `sessionSteps` from it.
    this.sessionSteps = 0; // This accumulates steps within the current GPS session
    this.lastEncounterCheck = null;
    this.encounterCooldown = 30000; // Original cooldown, now overridden in checkForEncounters
  }

  subscribe = (callback) => {
    this.subscribers.push(callback);
    callback(this.state);
    
    return () => {
      this.subscribers = this.subscribers.filter(sub => sub !== callback);
    };
  };

  updateState = (updates) => {
    this.state = { ...this.state, ...updates };
    this.subscribers.forEach(callback => callback(this.state));
  };

  start = (userStats) => {
    if (this.state.isTrackingLocation) {
      return { success: false, message: "GPS tracking is already active." };
    }

    if (!navigator.geolocation) {
      return { success: false, message: "Geolocation is not supported by this browser." };
    }

    this.initialUserStats = JSON.parse(JSON.stringify(userStats)); // Store a clean snapshot of initial stats
    this.sessionSteps = 0; // Always reset session steps on start

    this.updateState({ 
      isTrackingLocation: true, 
      userStats: userStats,
      gpsStatus: 'starting',
      sessionSteps: 0 // Also reset state session steps
    });

    const options = {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 5000
    };

    this.watchId = navigator.geolocation.watchPosition(
      this.handleLocationSuccess,
      this.handleLocationError,
      options
    );

    return { success: true, message: "GPS tracking started successfully!" };
  };

  stop = async () => {
    if (!this.state.isTrackingLocation) {
      return { success: false, message: "GPS tracking is not active." };
    }

    if (this.watchId !== null) {
      navigator.geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }

    const finalSessionSteps = this.sessionSteps; // Store before resetting

    // FIX: Use the initialUserStats snapshot as the base for calculations
    if (finalSessionSteps > 0 && this.initialUserStats) {
      try {
        const israelTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Jerusalem"});
        const todayFormatted = new Date(israelTime).toISOString().split('T')[0];
        const isNewDay = this.initialUserStats.last_step_date !== todayFormatted;
        
        // Use initial stats as the base to avoid race conditions or stale data
        const finalDailySteps = isNewDay ? finalSessionSteps : (this.initialUserStats.daily_steps || 0) + finalSessionSteps;
        const finalTotalSteps = (this.initialUserStats.total_steps || 0) + finalSessionSteps;
        
        console.log("=== GPS STOP: Final Step Calculation (Using Initial Stats) ===");
        console.log(`Session steps gained: ${finalSessionSteps}`);
        console.log(`Initial daily steps: ${this.initialUserStats.daily_steps || 0}`);
        console.log(`Initial total steps: ${this.initialUserStats.total_steps || 0}`);
        console.log(`Is new day: ${isNewDay}`);
        console.log(`Final daily steps to be saved: ${finalDailySteps}`);
        console.log(`Final total steps to be saved: ${finalTotalSteps}`);
        console.log("===============================================================");

        await updateUserData({
          total_steps: finalTotalSteps,
          daily_steps: finalDailySteps,
          last_step_date: todayFormatted,
        });

      } catch (error) {
        console.error("Failed to save final steps:", error);
      }
    }

    // Clear state
    this.updateState({ 
      isTrackingLocation: false,
      playerLocation: null,
      locationAccuracy: null,
      encounters: [], // Clear all encounters
      gpsStatus: 'inactive',
      sessionSteps: 0
    });
    
    this.lastPosition = null;
    this.sessionSteps = 0; // Reset after use
    this.initialUserStats = null; // Clear the snapshot

    return { success: true, message: `GPS tracking stopped. You gained ${finalSessionSteps} steps this session!` };
  };

  handleLocationSuccess = async (position) => {
    const { latitude, longitude, accuracy } = position.coords;
    
    console.log(`📍 GPS Update: ${latitude.toFixed(6)}, ${longitude.toFixed(6)} (±${Math.round(accuracy)}m)`);

    let gpsStatus = 'active';
    if (accuracy > 100) {
      gpsStatus = 'improving';
    } else if (accuracy > 50) {
      gpsStatus = 'starting';
    }

    this.updateState({
      playerLocation: { latitude, longitude },
      locationAccuracy: accuracy,
      gpsStatus: gpsStatus
    });

    // FIX: Always attempt to process movement and let the function's internal logic
    // decide if the movement is valid, rather than blocking based on accuracy here.
    await this.processMovement(latitude, longitude, accuracy, position.timestamp);

    if (accuracy <= MIN_ACCURACY_FOR_ENCOUNTERS) {
      await this.checkForEncounters(latitude, longitude);
    } else {
      console.log(`🎯 Accuracy too low for encounter generation: ${Math.round(accuracy)}m (need ≤${MIN_ACCURACY_FOR_ENCOUNTERS}m)`);
    }
  };

  handleLocationError = (error) => {
    console.error("GPS Error:", error);
    let errorMessage = "Unknown GPS error";
    
    switch (error.code) {
      case error.PERMISSION_DENIED:
        errorMessage = "Location access denied. Please enable location permissions.";
        break;
      case error.POSITION_UNAVAILABLE:
        errorMessage = "Location information unavailable. Please check your GPS signal.";
        break;
      case error.TIMEOUT:
        errorMessage = "Location request timed out. Trying again...";
        break;
      default: // Added default case to catch other errors
        errorMessage = `GPS error ${error.code}: ${error.message}`;
        break;
    }

    this.updateState({ 
      gpsStatus: 'error'
    });
  };

  processMovement = async (latitude, longitude, accuracy, timestamp) => {
    if (this.lastPosition) {
      const distance = this.calculateDistance(
        this.lastPosition.latitude,
        this.lastPosition.longitude,
        latitude,
        longitude
      );

      const timeDiff = timestamp - this.lastPosition.timestamp;
      const speed = distance / (timeDiff / 1000); // meters per second
      const maxSpeed = 5.0;

      console.log(`📊 GPS Movement Analysis: Distance=${distance.toFixed(2)}m, Speed=${speed.toFixed(2)}m/s, TimeDiff=${timeDiff}ms, Accuracy=${accuracy.toFixed(1)}m`);

      // FIX: Much more sensitive detection for slow walking
      if (distance > 0.3 && distance < 200 && speed <= maxSpeed && timeDiff > 500) {
        const steps = Math.max(1, Math.floor(distance * 1.4)); // Slightly more generous conversion
        this.sessionSteps += steps;
        
        console.log(`✅ STEPS COUNTED: ${distance.toFixed(1)}m = ${steps} steps (Total Session: ${this.sessionSteps})`);

        if (this.state.userStats) {
          const israelTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Jerusalem"});
          const todayFormatted = new Date(israelTime).toISOString().split('T')[0];
          
          const isNewDay = this.state.userStats.last_step_date !== todayFormatted;
          
          // FIX: Don't update total/daily steps in real-time during GPS session
          // Just keep session steps separate and add them at the end
          // This prevents race conditions and overwrites
          
          const updatedUserStats = {
            ...this.state.userStats,
            // Keep original daily/total steps unchanged during session
            last_step_date: todayFormatted
          };

          this.updateState({
            sessionSteps: this.sessionSteps,
            userStats: updatedUserStats
          });
        }
      } else {
        console.log(`❌ Movement rejected: Distance=${distance.toFixed(2)}m, Speed=${speed.toFixed(2)}m/s, TimeDiff=${timeDiff}ms`);
        if (speed > maxSpeed) console.log(`   Reason: Too fast (${speed.toFixed(1)} > ${maxSpeed} m/s)`);
        if (distance <= 0.3) console.log(`   Reason: Too small (${distance.toFixed(2)} <= 0.3m)`);
        if (distance >= 200) console.log(`   Reason: Too large (${distance.toFixed(2)} >= 200m)`);
        if (timeDiff <= 500) console.log(`   Reason: Too frequent (${timeDiff} <= 500ms)`);
      }
    }

    this.lastPosition = { latitude, longitude, accuracy, timestamp };
  };

  checkForEncounters = async (latitude, longitude) => {
    const now = Date.now();
    
    // FIX: Increase cooldown to 60 seconds to reduce Azure Function calls
    const encounterCooldown = 60000; // 60 seconds
    
    if (this.lastEncounterCheck && (now - this.lastEncounterCheck) < encounterCooldown) {
      return;
    }

    this.lastEncounterCheck = now;

    try {
      console.log("🔍 Checking for nearby encounters...");
      
      // FIX: Add retry logic with exponential backoff
      const { data: nearbyData } = await this.retryWithBackoff(() => getNearbyEncounters({
        latitude,
        longitude,
        radius: 100
      }));
      
      const nearbyEncounters = nearbyData?.encounters;
      if (!Array.isArray(nearbyEncounters)) {
          console.error("The 'encounters' property in the API response is not an array. Full response:", nearbyData);
          return;
      }

      console.log(`📊 Found ${nearbyEncounters.length} encounters in database`);

      const activeEncounters = nearbyEncounters.filter(encounter => 
        encounter.is_active && new Date(encounter.expires_at) > new Date()
      );

      console.log(`✅ ${activeEncounters.length} active encounters after filtering`);

      if (activeEncounters.length === 0) {
        console.log("🎲 Area is clear! Spawning 3 new encounters...");
        
        // FIX: Create encounters one at a time with delays to avoid rate limiting
        const encountersCreated = [];
        for (let i = 0; i < 3; i++) {
          const encounterType = Math.random() < 0.7 ? "monster" : "treasure";
          // Increased offset slightly as per outline
          const offsetLat = (Math.random() - 0.5) * 0.002;
          const offsetLng = (Math.random() - 0.5) * 0.002;
          
          const encounterLat = latitude + offsetLat;
          const encounterLng = longitude + offsetLng;
          
          const distanceToEncounter = this.calculateDistance(latitude, longitude, encounterLat, encounterLng);
          const walkingSpeed = 1.4; // meters per second (5 km/h)
          const walkingTimeSeconds = distanceToEncounter / walkingSpeed; // FIX: Define walkingTimeSeconds
          const bufferMultiplier = 3;
          const expirationMinutes = Math.max(5, Math.min(20, (walkingTimeSeconds * bufferMultiplier) / 60));
          
          const expirationDate = new Date();
          expirationDate.setMinutes(expirationDate.getMinutes() + expirationMinutes);

          const encounterData = {
            latitude: encounterLat,
            longitude: encounterLng,
            encounter_type: encounterType,
            expires_at: expirationDate.toISOString()
          };
          
          console.log(`📍 Creating encounter ${i + 1}/3: ${distanceToEncounter.toFixed(0)}m away, expires in ${expirationMinutes.toFixed(1)} minutes`);
          
          try {
            // FIX: Add retry logic and delay between requests
            const result = await this.retryWithBackoff(() => createRandomEncounter(encounterData));
            encountersCreated.push(result);
            
            // Add delay between requests to avoid rate limiting
            if (i < 2) { // Don't delay after the last one
              await new Promise(resolve => setTimeout(resolve, 1000)); // 1 second delay
            }
          } catch (encounterError) {
            console.error(`❌ Failed to create encounter ${i + 1}:`, encounterError.message || encounterError);
            // Continue with other encounters even if one fails
          }
        }
        
        console.log(`🎯 Created ${encountersCreated.length}/3 encounters successfully`);
        
        // FIX: Better logging and filtering to ensure we get all 3 encounters
        try {
          const { data: updatedEncountersResponse } = await this.retryWithBackoff(() => getNearbyEncounters({
            latitude,
            longitude,
            radius: 100
          }));

          const updatedEncounters = Array.isArray(updatedEncountersResponse?.encounters) 
            ? updatedEncountersResponse.encounters 
            : [];

          console.log(`🔄 Raw encounters from DB: ${updatedEncounters.length}`);
          
          const validEncounters = updatedEncounters.filter(e => {
            const isActive = e.is_active;
            const notExpired = new Date(e.expires_at) > new Date();
            console.log(`Encounter ${e.id}: active=${isActive}, expires=${e.expires_at}, notExpired=${notExpired}`);
            return isActive && notExpired;
          });

          console.log(`🔄 Valid encounters after filtering: ${validEncounters.length}`);

          this.updateState({
            encounters: validEncounters
          });
        } catch (refreshError) {
          console.error("❌ Failed to refresh encounters list:", refreshError.message || refreshError);
        }
      } else {
        console.log(`⏸️ Area not clear: ${activeEncounters.length} active encounters remain`);
        
        this.updateState({
          encounters: activeEncounters
        });
      }
    } catch (error) {
      console.error("Error checking for encounters:", error.message || error);
      // Don't break GPS tracking if encounter check fails
    }
  };

  // FIX: Add method to manually reload encounters
  reloadEncounters = async (latitude, longitude) => {
    try {
      console.log("🔄 Manually reloading encounters...");
      const { data: nearbyData } = await this.retryWithBackoff(() => getNearbyEncounters({
        latitude,
        longitude,
        radius: 100
      }));
      
      const nearbyEncounters = nearbyData?.encounters || [];
      const activeEncounters = nearbyEncounters.filter(encounter => 
        encounter.is_active && new Date(encounter.expires_at) > new Date()
      );

      console.log(`🔄 Reloaded ${activeEncounters.length} active encounters`);
      
      this.updateState({
        encounters: activeEncounters
      });

      // If no encounters, trigger creation of new ones
      if (activeEncounters.length === 0) {
        console.log("🎲 No encounters found, forcing new encounter creation...");
        this.lastEncounterCheck = null; // Reset cooldown
        await this.checkForEncounters(latitude, longitude);
      }
    } catch (error) {
      console.error("❌ Failed to reload encounters:", error);
    }
  };

  // FIX: Add retry logic with exponential backoff
  retryWithBackoff = async (fn, maxRetries = 3, baseDelay = 1000) => {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        return await fn();
      } catch (error) {
        console.log(`Attempt ${attempt}/${maxRetries} failed:`, error.message || error);
        
        // If it's a rate limit error or server error, retry
        if (attempt < maxRetries && (
          error.message?.includes('Rate limit') || 
          error.message?.includes('502') || 
          error.message?.includes('503') ||
          error.response?.status === 429 ||
          error.response?.status === 502 ||
          error.response?.status === 503
        )) {
          const delay = baseDelay * Math.pow(2, attempt - 1); // Exponential backoff
          console.log(`⏳ Retrying in ${delay}ms...`);
          await new Promise(resolve => setTimeout(resolve, delay));
        } else {
          throw error; // Re-throw if not retryable or max attempts reached
        }
      }
    }
  };

  calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371e3; // metres
    const φ1 = lat1 * Math.PI / 180; // φ, λ in radians
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c; // in metres
  };

  setEncounters = (encounters) => {
    this.updateState({ encounters });
  };

  setUserStats = (userStats) => {
    this.updateState({ userStats });
  };
}

export const gpsService = new GpsService();
