
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, Sword, Star, Zap, CheckCircle, PackagePlus, Paperclip, XCircle } from "lucide-react";

const getItemIcon = (type) => {
  switch (type) {
    case "weapon": return Sword;
    case "armor": return Shield;
    case "accessory": return Star;
    case "consumable": return Zap;
    default: return Shield;
  }
};

const getRarityColor = (rarity) => {
  switch (rarity) {
    case "legendary": return "border-yellow-400/50";
    case "epic": return "border-purple-400/50";
    case "rare": return "border-blue-400/50";
    case "uncommon": return "border-green-400/50";
    default: return "border-slate-600/50";
  }
};

const getStatDisplayName = (statKey) => {
  const statNames = {
    strength: "STR",
    dexterity: "DEX",
    constitution: "CON",
    intelligence: "INT",
    wisdom: "WIS",
    charisma: "CHA",
    coin_bonus_percentage: "Coin Bonus"
  };
  return statNames[statKey] || statKey;
};

export default function InventoryItem({ item, onEquip, onUnequip, onUse }) {
  const Icon = getItemIcon(item.type);

  let statBonuses = null;
  if (item.stat_bonuses) {
    if (typeof item.stat_bonuses === 'object') {
      statBonuses = item.stat_bonuses;
    } else if (typeof item.stat_bonuses === 'string') {
      try {
        statBonuses = JSON.parse(item.stat_bonuses.replace(/'/g, '"'));
      } catch (e) { 
        console.error("Could not parse stat_bonuses string:", item.stat_bonuses); 
      }
    }
  }

  return (
    <Card className={`bg-stone-800/70 border ${getRarityColor(item.rarity)} transition-all duration-300 ${item.is_equipped ? 'gold-glow' : ''}`}>
      <CardContent className="p-3 space-y-3">
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0 w-10 h-10 bg-stone-700/50 rounded-md flex items-center justify-center">
            <Icon className="w-6 h-6 text-amber-300" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
                <h4 className="font-medium text-amber-100 leading-tight">{item.name}</h4>
                {item.quantity > 1 && <Badge variant="secondary" className="text-sm">x{item.quantity}</Badge>}
            </div>
            <Badge variant="outline" className="text-xs mt-1">{item.rarity}</Badge>
          </div>
          {item.is_equipped && <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" title="Equipped" />}
        </div>
        
        {statBonuses && (
          <div className="flex flex-wrap gap-2">
            {Object.entries(statBonuses).map(([stat, bonus]) =>
              Number(bonus) > 0 && (
                <Badge key={stat} variant="secondary" className="text-xs">
                  +{bonus}{stat === 'coin_bonus_percentage' ? '%' : ''} {getStatDisplayName(stat)}
                </Badge>
              )
            )}
          </div>
        )}

        {item.type !== "consumable" && (
          <Button
            onClick={() => (item.is_equipped ? onUnequip(item) : onEquip(item))}
            className="w-full"
            size="sm"
            variant={item.is_equipped ? "destructive" : "outline"}
          >
            {item.is_equipped ? <><XCircle className="w-4 h-4 mr-2"/>Unequip</> : <><Paperclip className="w-4 h-4 mr-2"/>Equip</>}
          </Button>
        )}

        {item.type === "consumable" && (
          <Button onClick={() => onUse(item)} className="w-full" size="sm" variant="outline">
            <PackagePlus className="w-4 h-4 mr-2"/>Use
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
