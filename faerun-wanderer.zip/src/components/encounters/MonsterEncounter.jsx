import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Swords, Shield, Heart, Skull, Coins, Trophy, User, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const getMonsterImageUrl = (monsterName) => {
  return `https://zoosync2.blob.core.windows.net/reportphoto/${monsterName}.jpg`;
};

export default function MonsterEncounter({ monster, userLevel, onComplete, onFlee }) {
    const [playerHealth, setPlayerHealth] = useState(100);
    const [monsterHealth, setMonsterHealth] = useState(100);
    const [combatLog, setCombatLog] = useState([]);
    const [gameOver, setGameOver] = useState(false);
    const [victory, setVictory] = useState(false);
    const isPlayerTurn = useRef(true);
    const logContainerRef = useRef(null);

    useEffect(() => {
      addLogMessage("You encountered a " + monster.name + "!");
    }, [monster.name]);

    useEffect(() => {
        if (logContainerRef.current) {
            logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
        }
    }, [combatLog]);

    const addLogMessage = (message) => {
        setCombatLog(prev => [...prev, message]);
    };

    const handleAttack = () => {
        if (gameOver || !isPlayerTurn.current) return;
        isPlayerTurn.current = false;

        // Player attacks
        const playerDamage = Math.floor(Math.random() * 10) + (userLevel * 2);
        const newMonsterHealth = Math.max(0, monsterHealth - playerDamage);
        addLogMessage(`You strike for ${playerDamage} damage!`);
        setMonsterHealth(newMonsterHealth);

        if (newMonsterHealth <= 0) {
            setGameOver(true);
            setVictory(true);
            addLogMessage("You defeated the " + monster.name + "!");
            return;
        }

        // Monster's turn after a delay
        setTimeout(() => {
            const monsterDamage = Math.floor(Math.random() * 15) + 1;
            const newPlayerHealth = Math.max(0, playerHealth - monsterDamage);
            addLogMessage(`${monster.name} attacks for ${monsterDamage} damage!`);
            setPlayerHealth(newPlayerHealth);

            if (newPlayerHealth <= 0) {
                setGameOver(true);
                setVictory(false);
                addLogMessage("You have been defeated...");
            }
            isPlayerTurn.current = true;
        }, 1000);
    };

    const handleFlee = () => {
        onFlee();
    };
    
    return (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-2 z-50">
            {/* FIX: Add max-height and scroll for very small screens */}
            <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="w-full max-w-md max-h-[95vh] overflow-y-auto"
            >
                <Card className="fantasy-border bg-gradient-to-br from-stone-800/95 to-red-900/80 backdrop-blur-sm">
                    {/* FIX: Reduced header padding */}
                    <CardHeader className="text-center p-4">
                        <CardTitle className="text-2xl text-red-300 flex items-center justify-center gap-3">
                            {gameOver ? (victory ? <Trophy /> : <Skull />) : <ShieldAlert className="w-7 h-7" />}
                            {gameOver ? (victory ? "Victory!" : "Defeat...") : "Monster Encounter!"}
                        </CardTitle>
                    </CardHeader>
                    
                    {/* FIX: Reduced content padding and spacing */}
                    <CardContent className="p-4 space-y-3">
                        {/* FIX: Reduced image height */}
                        <div className="w-full h-40 rounded-lg overflow-hidden bg-black/50 flex items-center justify-center">
                            <img 
                                src={getMonsterImageUrl(monster.name)} 
                                alt={monster.name}
                                className="w-full h-full object-contain"
                                onError={(e) => { e.target.src = `https://via.placeholder.com/300x200/8B4513/FFFFFF?text=${encodeURIComponent(monster.name)}`; }}
                            />
                        </div>
                        
                        <div className="text-center space-y-1">
                            <h3 className="text-xl font-bold text-amber-100">{monster.name}</h3>
                            <p className="text-xs text-amber-300/70">{monster.description}</p>
                            <div className="flex justify-center gap-4 text-amber-200 pt-1">
                                <Badge variant="outline" className="text-xs">
                                    <Trophy className="w-3 h-3 mr-1" /> CR {monster.challenge_rating}
                                </Badge>
                                <Badge variant="outline" className="text-xs">
                                    <Coins className="w-3 h-3 mr-1" /> {monster.gold_reward} Gold
                                </Badge>
                            </div>
                        </div>

                        {/* Health Bars */}
                        <div className="space-y-2 pt-3 border-t border-amber-800/30">
                            <div className="space-y-1">
                                <div className="flex justify-between text-sm">
                                    <span className="text-green-300 font-medium">Your Health</span>
                                    <span className="text-green-300">{playerHealth}/100</span>
                                </div>
                                <Progress value={playerHealth} className="h-3" />
                            </div>
                             <div className="space-y-1">
                                <div className="flex justify-between text-sm">
                                    <span className="text-red-300 font-medium">{monster.name} Health</span>
                                    <span className="text-red-300">{monsterHealth}/100</span>
                                </div>
                                <Progress value={monsterHealth} className="h-3" indicatorClassName="bg-red-500" />
                            </div>
                        </div>

                        {/* Combat Log */}
                        {/* FIX: Reduced combat log height */}
                        <div ref={logContainerRef} className="h-28 bg-black/30 rounded-lg p-2 space-y-1 overflow-y-auto text-xs">
                            <AnimatePresence>
                                {combatLog.map((log, index) => (
                                    <motion.p 
                                        key={index}
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        className={`text-slate-300 ${log.includes('You strike') ? 'text-green-400' : ''}`}
                                    >
                                        {log}
                                    </motion.p>
                                ))}
                            </AnimatePresence>
                        </div>

                        {/* Action Buttons */}
                        {!gameOver && (
                            <div className="grid grid-cols-2 gap-3 pt-3 border-t border-amber-800/30">
                                <Button onClick={handleAttack} disabled={isPlayerTurn.current === false}>
                                    <Swords className="w-4 h-4 mr-2" /> Attack
                                </Button>
                                <Button onClick={handleFlee} variant="destructive">
                                    <Shield className="w-4 h-4 mr-2" /> Flee
                                </Button>
                            </div>
                        )}

                        {gameOver && (
                            <div className="text-center pt-3 border-t border-amber-800/30">
                                <p className="text-sm text-amber-200 mb-3">
                                    {victory ? `You gained ${monster.gold_reward} gold!` : "You managed to escape, but gained nothing."}
                                </p>
                                <Button onClick={() => onComplete(victory, monster)} className="w-full">
                                    Continue Adventure
                                </Button>
                            </div>
                        )}
                    </CardContent>
                </Card>
            </motion.div>
        </div>
    );
}