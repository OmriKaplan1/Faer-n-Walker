import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Timer, Swords, Coins } from 'lucide-react';

function formatTime(ms) {
    if (ms <= 0) return "00:00";
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
    const seconds = (totalSeconds % 60).toString().padStart(2, '0');
    return `${minutes}:${seconds}`;
}

export default function EncounterPopupContent({ encounter }) {
    const [timeLeft, setTimeLeft] = useState(Math.max(0, new Date(encounter.expires_at) - new Date()));

    useEffect(() => {
        const timer = setInterval(() => {
            const newTimeLeft = new Date(encounter.expires_at) - new Date();
            if (newTimeLeft <= 0) {
                setTimeLeft(0);
                clearInterval(timer);
            } else {
                setTimeLeft(newTimeLeft);
            }
        }, 1000);

        return () => clearInterval(timer);
    }, [encounter.expires_at]);

    const isExpired = timeLeft <= 0;

    const encounterDetails = {
        monster: {
            title: "Monster Encounter",
            icon: <Swords className="w-5 h-5 text-red-400" />,
            description: "A creature lurks nearby...",
            color: "from-red-900/80 to-black/80"
        },
        treasure: {
            title: "Treasure Found",
            icon: <Coins className="w-5 h-5 text-yellow-400" />,
            description: "Something glints in the distance...",
            color: "from-yellow-900/80 to-black/80"
        }
    };
    
    const details = encounterDetails[encounter.encounter_type] || encounterDetails.monster;

    return (
        <div className="w-64 -m-4">
             <Card className={`fantasy-border bg-gradient-to-br ${details.color} backdrop-blur-sm text-amber-100 border-amber-800/50 shadow-lg`}>
                <CardHeader className="p-4">
                    <CardTitle className="flex items-center gap-3 text-lg">
                        {details.icon}
                        {details.title}
                    </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0 text-center space-y-4">
                    <p className="text-sm text-amber-300/70">{details.description}</p>
                    
                    <div className="flex items-center justify-center gap-2 p-2 bg-stone-900/50 rounded-lg">
                        <Timer className="w-4 h-4 text-orange-400" />
                        <span className={`font-mono font-bold text-lg ${isExpired ? 'text-red-500' : 'text-amber-200'}`}>
                            {formatTime(timeLeft)}
                        </span>
                    </div>

                    <p className={`text-xs font-semibold uppercase tracking-wider ${isExpired ? 'text-gray-500' : 'text-amber-300'}`}>
                        {isExpired ? 'This encounter has vanished' : 'Approach to interact'}
                    </p>
                </CardContent>
            </Card>
        </div>
    );
}