import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Coins, Footprints } from 'lucide-react';

export default function PoiPopupContent({ poi, isVisited }) {
    return (
        <div className="w-64 -m-4">
             <Card className="fantasy-border bg-gradient-to-br from-stone-800/95 to-amber-900/80 backdrop-blur-sm text-amber-100 border-amber-800/50 shadow-lg">
                <CardHeader className="p-4">
                    <CardTitle className="text-lg">
                        {poi.name}
                    </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0 space-y-3">
                    <p className="text-sm text-amber-300/70">{poi.description}</p>
                    
                    <div className="space-y-2 text-xs">
                        <div className="flex justify-between items-center">
                            <span className="text-amber-300/80 flex items-center gap-1"><Footprints className="w-3 h-3" /> Required:</span>
                            <span className="font-bold">{poi.steps_required.toLocaleString()} steps</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-amber-300/80 flex items-center gap-1"><Coins className="w-3 h-3" /> Reward:</span>
                            <span className="font-bold">{poi.coin_reward} Gold</span>
                        </div>
                    </div>
                    
                    <Badge variant={isVisited ? "default" : "secondary"} className="w-full justify-center">
                        {isVisited ? "✅ Visited" : `🏛️ ${poi.location_type}`}
                    </Badge>
                </CardContent>
            </Card>
        </div>
    );
}