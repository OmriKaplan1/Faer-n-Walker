import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Navigation } from 'lucide-react';

export default function PlayerPopupContent({ playerLocation, locationAccuracy }) {
    return (
        <div className="w-64 -m-4">
             <Card className="fantasy-border bg-gradient-to-br from-orange-900/80 to-black/80 backdrop-blur-sm text-amber-100 border-amber-800/50 shadow-lg">
                <CardHeader className="p-4">
                    <CardTitle className="flex items-center gap-3 text-lg">
                        <Navigation className="w-5 h-5 text-orange-400" />
                        Your Location
                    </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0 space-y-3">
                    <p className="text-sm text-amber-300/70 text-center">
                        You are here, brave adventurer!
                    </p>
                    <div className="text-xs space-y-1 text-amber-200 bg-stone-900/50 p-2 rounded-lg">
                        <div className="flex justify-between">
                            <span>Accuracy:</span>
                            <span>{Math.round(locationAccuracy || 0)}m</span>
                        </div>
                        <div className="flex justify-between">
                            <span>Latitude:</span>
                            <span>{playerLocation.latitude.toFixed(5)}</span>
                        </div>
                        <div className="flex justify-between">
                            <span>Longitude:</span>
                            <span>{playerLocation.longitude.toFixed(5)}</span>
                        </div>
                    </div>
                    <Badge variant="outline" className="w-full justify-center">
                        🎯 Live Location
                    </Badge>
                </CardContent>
            </Card>
        </div>
    );
}