import React, { createContext, useState, useEffect, useContext } from 'react';
import { gpsService } from './GpsService'; // Import the service instance

const GpsContext = createContext(null);

export const useGps = () => {
  const context = useContext(GpsContext);
  if (!context) {
    throw new Error('useGps must be used within a GpsProvider');
  }
  return context;
};

export const GpsProvider = ({ children }) => {
  // State in the provider now just mirrors the service's state
  const [gpsState, setGpsState] = useState(gpsService.state);

  useEffect(() => {
    // Subscribe to the service on mount, and unsubscribe on unmount.
    // The subscribe function now immediately provides the current state.
    const unsubscribe = gpsService.subscribe(setGpsState);
    
    // FIX: Expose the GPS service globally so it can be accessed for encounter reloading
    window.gpsService = gpsService;
    
    return () => {
      unsubscribe();
      delete window.gpsService;
    };
  }, []);

  // The value provided by the context now wraps the service's methods and state
  const value = {
    ...gpsState, // Spread the current state (isTrackingLocation, playerLocation, etc.)
    startLocationTracking: gpsService.start, // Expose the service's start method
    stopLocationTracking: gpsService.stop,   // Expose the service's stop method
    setEncounters: gpsService.setEncounters, // Expose state setters
    setUserStats: gpsService.setUserStats,   // Expose state setters
    reloadEncounters: gpsService.reloadEncounters, // FIX: Expose reload method
  };

  return <GpsContext.Provider value={value}>{children}</GpsContext.Provider>;
};