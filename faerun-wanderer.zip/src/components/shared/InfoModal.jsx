import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function InfoModal({ title, message, icon, onClose, buttonText = "Continue" }) {
  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-[100]">
        <motion.div
          initial={{ opacity: 0, scale: 0.8, y: 50 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: 50 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          className="max-w-md w-full"
        >
          <Card className="fantasy-border bg-gradient-to-br from-stone-800/95 to-amber-900/80 backdrop-blur-lg">
            <CardHeader className="flex flex-row items-start justify-between">
              <div className="flex items-center gap-3">
                {icon && (
                  <div className="w-12 h-12 flex-shrink-0 bg-amber-600/10 rounded-lg flex items-center justify-center border border-amber-500/20">
                    {icon}
                  </div>
                )}
                <CardTitle className="text-xl text-amber-100">{title}</CardTitle>
              </div>
              <Button variant="ghost" size="icon" onClick={onClose} className="text-amber-300/70 hover:text-amber-100 -mt-2 -mr-2">
                <X className="w-5 h-5" />
              </Button>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-amber-300/80 text-base leading-relaxed">
                {message}
              </p>
              <Button
                onClick={onClose}
                className="w-full bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-700 hover:to-yellow-700 text-stone-900 font-bold"
              >
                {buttonText}
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}