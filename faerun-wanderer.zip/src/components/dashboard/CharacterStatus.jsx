import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Shield, Coins, Star, Sword } from "lucide-react";
import { motion } from "framer-motion";

// NEW: Progressive level calculation function (same as Dashboard)
const calculateLevel = (totalSteps) => {
  let level = 1;
  let stepsUsed = 0;
  
  while (stepsUsed + (level * 5000) <= totalSteps) {
    stepsUsed += level * 5000;
    level++;
  }
  
  return level;
};

const calculateLevelProgress = (totalSteps, currentLevel) => {
  let level = 1;
  let stepsUsed = 0;
  
  // Calculate steps used for all previous levels
  while (level < currentLevel) {
    stepsUsed += level * 5000;
    level++;
  }
  
  // Steps needed for current level (5000 * current level)
  const stepsNeededForCurrentLevel = currentLevel * 5000;
  const stepsIntoCurrentLevel = totalSteps - stepsUsed;
  
  return {
    current: stepsIntoCurrentLevel,
    needed: stepsNeededForCurrentLevel,
    progress: (stepsIntoCurrentLevel / stepsNeededForCurrentLevel) * 100
  };
};

export default function CharacterStatus({ userStats }) {
  const getClassIcon = (characterClass) => {
    switch (characterClass) {
      case "Fighter": return Shield;
      case "Wizard": return Star;
      case "Rogue": return Sword;
      default: return Shield;
    }
  };

  const ClassIcon = getClassIcon(userStats?.character_class);
  
  // Use the new progressive level calculation
  const totalSteps = userStats?.total_steps || 0;
  const level = calculateLevel(totalSteps);
  const levelProgress = calculateLevelProgress(totalSteps, level);

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 0.2 }}
    >
      <Card className="fantasy-border bg-stone-800/90 backdrop-blur-sm border-stone-600/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-slate-100">
            <ClassIcon className="w-6 h-6 text-purple-400" />
            Character Status
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-slate-100 mb-1">
              {userStats?.character_name || "Unnamed Hero"}
            </div>
            <div className="text-slate-300">
              Level {level} {userStats?.character_class || "Fighter"}
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm text-slate-200">
              <span>Experience</span>
              <span>{levelProgress.current.toLocaleString()}/{levelProgress.needed.toLocaleString()}</span>
            </div>
            <Progress 
              value={levelProgress.progress} 
              className="h-2 bg-stone-700"
            />
            <div className="text-xs text-slate-400 text-center">
              Next level: {(levelProgress.needed - levelProgress.current).toLocaleString()} steps needed
            </div>
          </div>

          <div className="flex items-center justify-center gap-2 p-3 rounded-lg bg-amber-600/20 border border-amber-600/30">
            <Coins className="w-5 h-5 text-amber-400" />
            <span className="text-lg font-bold text-slate-100">
              {userStats?.coins || 0} Gold
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="text-center p-2 rounded bg-stone-700/70 border border-stone-600/50">
              <div className="text-slate-100 font-medium">Locations</div>
              <div className="text-slate-300">{userStats?.visited_locations?.length || 0}</div>
            </div>
            <div className="text-center p-2 rounded bg-stone-700/70 border border-stone-600/50">
              <div className="text-slate-100 font-medium">Adventures</div>
              <div className="text-slate-300">{Math.floor((userStats?.total_steps || 0) / 10000)}</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}