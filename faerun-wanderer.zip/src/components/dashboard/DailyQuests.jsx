
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Scroll, CheckCircle, Clock, Coins, Trophy } from "lucide-react";
import { motion } from "framer-motion";

// Function to get current time in Israel timezone
const getIsraeliTime = () => {
  return new Date(new Date().toLocaleString("en-US", {timeZone: "Asia/Jerusalem"}));
};

// Function to check if it's currently before noon in Israel
const isBeforeNoonInIsrael = () => {
  const israelTime = getIsraeliTime();
  return israelTime.getHours() < 12;
};

export default function DailyQuests({ userStats }) {
  // FIX 3: Stricter morning patrol logic - quest is only completable before noon AND only if currently before noon
  const morningPatrolProgress = () => {
    const currentSteps = userStats?.daily_steps || 0;
    const isCurrentlyMorning = isBeforeNoonInIsrael();
    
    // If it's currently past noon, don't show any new progress
    if (!isCurrentlyMorning && currentSteps < 2500) {
      return 0; // No progress allowed past noon
    }
    
    return Math.min(currentSteps, 2500);
  };

  const morningPatrolCompleted = () => {
    const currentSteps = userStats?.daily_steps || 0;
    return currentSteps >= 2500;
  };

  const morningPatrolCanComplete = () => {
    const isCurrentlyMorning = isBeforeNoonInIsrael();
    const hasEnoughSteps = (userStats?.daily_steps || 0) >= 2500;
    
    // Quest can only be completed if it's currently morning OR already completed
    return (isCurrentlyMorning && hasEnoughSteps) || morningPatrolCompleted();
  };

  // FIXED: Calculate milestone achievement progress
  const totalSteps = userStats?.total_steps || 0;
  const nextMilestone = Math.ceil(totalSteps / 1000) * 1000;
  const progressToMilestone = totalSteps % 1000;

  const quests = [
    {
      id: 1,
      title: "Morning Patrol",
      description: `Take 2,500 steps before noon (${isBeforeNoonInIsrael() ? 'Still time!' : 'Time expired'})`,
      progress: morningPatrolProgress(),
      target: 2500,
      reward: 50,
      completed: morningPatrolCanComplete() && morningPatrolCompleted(),
      timeExpired: !isBeforeNoonInIsrael() && !morningPatrolCompleted()
    },
    {
      id: 2,
      title: "Explorer's Journey",
      description: "Reach your daily step goal",
      progress: Math.min((userStats?.daily_steps || 0), 10000),
      target: 10000,
      reward: 100,
      completed: (userStats?.daily_steps || 0) >= 10000
    },
    {
      id: 3,
      title: "Milestone Walker",
      description: `Reach your next step milestone (${nextMilestone.toLocaleString()} total steps)`,
      progress: progressToMilestone,
      target: 1000,
      reward: 25,
      completed: totalSteps >= nextMilestone && totalSteps > 0 && (totalSteps % 1000 === 0)
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
    >
      <Card className="fantasy-border bg-stone-800/90 backdrop-blur-sm border-stone-600/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-slate-100">
            <Scroll className="w-6 h-6 text-green-400" />
            Daily Quests
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {quests.map((quest) => (
            <motion.div
              key={quest.id}
              className={`p-4 rounded-lg border transition-all duration-300 ${
                quest.completed 
                  ? 'bg-green-900/30 border-green-600/40' 
                  : quest.timeExpired
                  ? 'bg-red-900/20 border-red-600/40'
                  : 'bg-stone-700/50 border-stone-600/50'
              }`}
              whileHover={{ scale: 1.02 }}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-medium text-slate-100">{quest.title}</h4>
                    {quest.completed && (
                      <CheckCircle className="w-4 h-4 text-green-400" />
                    )}
                    {quest.timeExpired && (
                      <Clock className="w-4 h-4 text-red-400" />
                    )}
                    {quest.id === 3 && (
                      <Trophy className="w-4 h-4 text-amber-400" />
                    )}
                  </div>
                  <p className={`text-sm ${
                    quest.timeExpired ? 'text-red-300' : 'text-slate-300'
                  }`}>
                    {quest.description}
                  </p>
                  {quest.timeExpired && (
                    <p className="text-xs text-red-400 mt-1">
                      This quest can no longer be completed today
                    </p>
                  )}
                </div>
                <Badge 
                  variant="outline" 
                  className="flex items-center gap-1 border-amber-600/50 text-amber-300 bg-amber-600/10"
                >
                  <Coins className="w-3 h-3" />
                  {quest.reward}
                </Badge>
              </div>
              
              {!quest.completed && quest.target > 1 && (
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-slate-200">
                    <span>Progress</span>
                    <span>{quest.progress}/{quest.target}</span>
                  </div>
                  <Progress 
                    value={(quest.progress / quest.target) * 100} 
                    className={`h-2 ${
                      quest.timeExpired ? 'bg-red-900/50' : 'bg-stone-600'
                    }`}
                  />
                </div>
              )}
            </motion.div>
          ))}
        </CardContent>
      </Card>
    </motion.div>
  );
}
