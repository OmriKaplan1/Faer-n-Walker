
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Footprints, Target, TrendingUp, MapPin, Navigation, PlusCircle } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useGps } from "@/components/GpsProvider";
import { updateUserData } from "@/api/functions";

export default function StepCounter({ userStats, onUpdate }) {
  const { isTrackingLocation, gpsStatus, sessionSteps } = useGps();
  const [manualSteps, setManualSteps] = useState("");
  
  const dailyGoal = 10000;
  // FIX: Show current daily steps + session steps for accurate display
  const displaySteps = (userStats?.daily_steps || 0) + (sessionSteps || 0);
  const progressPercentage = Math.min((displaySteps / dailyGoal) * 100, 100);

  const handleAddManualSteps = async () => {
    const stepsToAdd = parseInt(manualSteps, 10);
    if (isNaN(stepsToAdd) || stepsToAdd <= 0) {
      alert("Please enter a valid positive number of steps.");
      return;
    }

    const today = new Date().toISOString().split('T')[0];
    const isNewDay = userStats.last_step_date !== today;

    const newDailySteps = isNewDay ? stepsToAdd : (userStats.daily_steps || 0) + stepsToAdd;
    const newTotalSteps = (userStats.total_steps || 0) + stepsToAdd;

    try {
      await updateUserData({
        total_steps: newTotalSteps,
        daily_steps: newDailySteps,
        last_step_date: today,
      });
      setManualSteps("");
      if (onUpdate) {
        onUpdate(); // Trigger refresh of user data on Dashboard
      }
    } catch (error) {
      console.error("Failed to add manual steps:", error);
      alert("Failed to add steps. Please try again.");
    }
  };

  const getGpsStatusDisplay = () => {
    switch (gpsStatus) {
      case 'starting':
        return { text: '🟡 Getting Satellite Lock...', color: 'text-yellow-400', iconColor: 'text-yellow-400' };
      case 'improving':
        return { text: '🟠 Improving GPS Signal...', color: 'text-orange-400', iconColor: 'text-orange-400' };
      case 'active':
        return { text: '🟢 GPS Adventure Active', color: 'text-green-400', iconColor: 'text-green-400' };
      case 'error':
        return { text: '🔴 GPS Signal Lost', color: 'text-red-400', iconColor: 'text-red-400' };
      default: // 'inactive' or undefined
        return { text: '⚫ GPS Inactive', color: 'text-gray-400', iconColor: 'text-gray-400' };
    }
  };

  const statusDisplay = getGpsStatusDisplay();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4 w-full"
    >
      <Card className="fantasy-border bg-stone-800/90 backdrop-blur-sm border-stone-600/50 w-full">
        <CardHeader className="p-4 sm:p-6">
          <CardTitle className="flex items-center gap-2 text-slate-100 text-lg sm:text-xl">
            <Footprints className="w-5 h-5 sm:w-6 sm:h-6 text-amber-400" />
            Today's Journey
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 sm:space-y-6 p-4 sm:p-6 pt-0">
          <div className="text-center">
            <div className="text-3xl sm:text-4xl font-bold text-slate-100 mb-2">
              {displaySteps.toLocaleString()}
            </div>
            <div className="text-slate-300 text-sm sm:text-base">steps taken</div>
            {/* FIX: Show session steps separately when GPS is active */}
            {isTrackingLocation && sessionSteps > 0 && (
              <div className="text-xs text-green-400 mt-1">
                +{sessionSteps} steps this adventure
              </div>
            )}
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-xs sm:text-sm text-slate-200">
              <span>Progress to Goal</span>
              <span>{Math.round(progressPercentage)}%</span>
            </div>
            <Progress 
              value={progressPercentage} 
              className="h-2 sm:h-3 bg-stone-700 w-full"
            />
            <div className="text-xs text-slate-400 text-center">
              Goal: {dailyGoal.toLocaleString()} steps
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 sm:gap-4">
            <div className="text-center p-2 sm:p-3 rounded-lg bg-stone-700/70 border border-stone-600/50">
              <Target className="w-4 h-4 sm:w-5 sm:h-5 text-green-400 mx-auto mb-1" />
              <div className="text-xs sm:text-sm text-slate-100 font-medium">
                {Math.max(0, dailyGoal - displaySteps).toLocaleString()}
              </div>
              <div className="text-xs text-slate-300">remaining</div>
            </div>
            <div className="text-center p-2 sm:p-3 rounded-lg bg-stone-700/70 border border-stone-600/50">
              <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-blue-400 mx-auto mb-1" />
              <div className="text-xs sm:text-sm text-slate-100 font-medium">
                {((userStats?.total_steps || 0) + (sessionSteps || 0)).toLocaleString()}
              </div>
              <div className="text-xs text-slate-300">total steps</div>
            </div>
          </div>

          {/* Updated GPS Status Indicator */}
          {isTrackingLocation && (
            <div className={`flex items-center justify-center gap-2 p-2 rounded-lg ${
              gpsStatus === 'active' ? 'bg-green-600/20 border-green-600/30' :
              gpsStatus === 'starting' ? 'bg-yellow-600/20 border-yellow-600/30' :
              gpsStatus === 'improving' ? 'bg-orange-600/20 border-orange-600/30' :
              gpsStatus === 'error' ? 'bg-red-600/20 border-red-600/30' :
              'bg-gray-600/20 border-gray-600/30'
            }`}>
              <Navigation className={`w-4 h-4 ${statusDisplay.iconColor}`} />
              <span className={`text-sm font-medium ${statusDisplay.color}`}>
                {statusDisplay.text}
              </span>
            </div>
          )}

          <Link to={createPageUrl("Map")}>
            <Button className="w-full bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-700 hover:to-yellow-700 text-slate-900 font-bold py-2 sm:py-3 gold-glow transition-all duration-300 text-sm sm:text-base">
              <MapPin className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
              {isTrackingLocation ? "View Active Adventure" : "Start Adventure on Map"}
            </Button>
          </Link>

          <div className="text-xs text-slate-400 text-center">
            💡 Go to the Map page to start GPS tracking and earn steps by walking!
          </div>
        </CardContent>
        
        {/* **FIX 3: Manual Step Entry** */}
        <CardFooter className="p-4 sm:p-6 border-t border-stone-600/30">
          <div className="w-full space-y-3">
            <h4 className="flex items-center gap-2 text-sm font-medium text-slate-100">
              <PlusCircle className="w-4 h-4 text-green-400" />
              Manual Step Entry
            </h4>
            <div className="flex gap-2">
              <Input
                type="number"
                placeholder="Enter steps..."
                value={manualSteps}
                onChange={(e) => setManualSteps(e.target.value)}
                className="bg-stone-700/50 border-amber-600/30 text-amber-100 placeholder:text-stone-400"
              />
              <Button onClick={handleAddManualSteps} variant="outline" className="border-amber-600/30 text-amber-300 hover:bg-amber-700/20 hover:text-amber-100">
                Add
              </Button>
            </div>
            <p className="text-xs text-slate-400 text-center">
              For adding steps when you were away from your phone.
            </p>
          </div>
        </CardFooter>
      </Card>
    </motion.div>
  );
}
