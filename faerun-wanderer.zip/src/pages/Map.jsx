
import React, { useState, useEffect, useRef, useCallback } from "react";
import { MapContainer, TileLayer, Marker, Popup, Circle } from "react-leaflet";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { listPointsOfInterest } from "@/api/functions";
import { createPlayerEncounter } from "@/api/functions";
import { listMonsters } from "@/api/functions";
import { getUserData } from "@/api/functions";
import { updateUserData } from "@/api/functions";
import { getMapKey } from "@/api/functions";
import { deleteRandomEncounter } from "@/api/functions";
import MonsterEncounter from "../components/encounters/MonsterEncounter";
import InfoModal from "../components/shared/InfoModal";
import { MapPin, Coins, Lock, CheckCircle, Navigation, Target, Swords, AlertTriangle, Shield, Star, Footprints, Timer } from "lucide-react";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { AnimatePresence } from "framer-motion";
import { useGps } from "@/components/GpsProvider";
import EncounterPopupContent from "../components/map/EncounterPopupContent";
import PoiPopupContent from "../components/map/PoiPopupContent";
import PlayerPopupContent from "../components/map/PlayerPopupContent";

// Fix Leaflet default markers
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Create custom icons
const poiIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const encounterIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const treasureIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-gold.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const visitedIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const playerIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-orange.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [30, 49],
  iconAnchor: [15, 49],
  popupAnchor: [1, -40],
  shadowSize: [50, 50]
});

const TAU_CENTER = [32.1131, 34.8042];

const INTERACTION_RADIUS_METERS = 30; // Proximity requirement in meters

const calculateDistance = (lat1, lon1, lat2, lon2) => {
    if (!lat1 || !lon1 || !lat2 || !lon2) return Infinity;
    const R = 6371e3;
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c;
};

export default function Map() {
  const [pois, setPois] = useState([]);
  const [monsters, setMonsters] = useState([]);
  const [selectedPoi, setSelectedPoi] = useState(null);
  const [activeEncounter, setActiveEncounter] = useState(null);
  const [encounterMonster, setEncounterMonster] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [mapKey, setMapKey] = useState(null);
  const [mapError, setMapError] = useState(null);
  const [mapInstance, setMapInstance] = useState(null);
  const [notification, setNotification] = useState({ isOpen: false, title: '', message: '', icon: null });
  const mapContainerRef = useRef(null);
  
  const {
    isTrackingLocation,
    playerLocation,
    locationAccuracy,
    encounters,
    setEncounters,
    startLocationTracking,
    stopLocationTracking,
    userStats: contextUserStats,
    setUserStats: setContextUserStats,
    sessionSteps,
    gpsStatus
  } = useGps();

  const [localUserStats, setLocalUserStats] = useState(null);

  useEffect(() => {
    const initializeMap = async () => {
      setIsLoading(true);
      setMapError(null);
      try {
        console.log("Requesting Azure Maps key...");
        const { data: keyData } = await getMapKey();

        if (!keyData || !keyData.key) {
          console.error("Azure Maps key was not received from the backend.");
          setMapError("Could not retrieve the map key. Please ensure it's set correctly in the secrets.");
          setIsLoading(false);
          return;
        }
        
        console.log("Received Azure Maps Key (first 10 chars):", keyData.key.substring(0, 10));
        console.log("Full key length:", keyData.key.length);
        setMapKey(keyData.key);
        
        const [poisRes, monstersRes, userRes] = await Promise.all([
          listPointsOfInterest(),
          listMonsters(),
          getUserData()
        ]);

        setPois(poisRes.data);
        setMonsters(monstersRes.data);
        
        let visitedLocations = [];
        if (userRes.data.visited_locations) {
          if (Array.isArray(userRes.data.visited_locations)) {
            visitedLocations = userRes.data.visited_locations;
          } else if (typeof userRes.data.visited_locations === 'string') {
            try {
              visitedLocations = JSON.parse(userRes.data.visited_locations);
            } catch (e) {
              console.error("Could not parse visited_locations:", userRes.data.visited_locations, e);
              visitedLocations = [];
            }
          }
        }

        const processedUserStats = {
          ...userRes.data,
          visited_locations: visitedLocations
        };

        setLocalUserStats(processedUserStats);
        setContextUserStats(processedUserStats);
        
      } catch (error) {
        console.error("Error initializing map:", error);
        setMapError("An error occurred while loading map data.");
      }
      setIsLoading(false);
    };

    initializeMap();
  }, [setContextUserStats]);

  const handleStartGPS = () => {
    const result = startLocationTracking(localUserStats); 
    setNotification({
      isOpen: true,
      title: result.success ? "Adventure Started!" : "GPS Error",
      message: result.message,
      icon: result.success 
        ? <Navigation className="w-8 h-8 text-blue-400" />
        : <AlertTriangle className="w-8 h-8 text-red-400" />
    });
  };

  const handleStopGPS = async () => {
    try {
      const result = await stopLocationTracking();
      setNotification({
        isOpen: true,
        title: result.success ? "Adventure Ended" : "GPS Error",
        message: result.message,
        icon: result.success 
          ? <Navigation className="w-8 h-8 text-gray-400" />
          : <AlertTriangle className="w-8 h-8 text-red-400" />
      });
    } catch (error) {
      console.error("Error stopping GPS:", error);
      setNotification({
        isOpen: true,
        title: "GPS Error",
        message: "There was an error stopping the GPS tracking.",
        icon: <AlertTriangle className="w-8 h-8 text-red-400" />
      });
    }
  };

  // PROPER FIX: Wait for container to have final dimensions before calling invalidateSize
  useEffect(() => {
    if (!mapInstance || !mapContainerRef.current) return;

    const waitForFinalSize = () => {
      const container = mapContainerRef.current;
      const rect = container.getBoundingClientRect();
      
      // Only invalidate when container has actual dimensions
      if (rect.width > 0 && rect.height > 0) {
        console.log(`Container has final size: ${rect.width}x${rect.height}, calling invalidateSize`);
        mapInstance.invalidateSize();
        return true;
      }
      return false;
    };

    // Strategy 1: Immediate check
    if (!waitForFinalSize()) {
      // Strategy 2: Use requestAnimationFrame to wait for next paint cycle
      requestAnimationFrame(() => {
        if (!waitForFinalSize()) {
          // Strategy 3: Small delay for complex layouts
          setTimeout(() => {
            waitForFinalSize();
          }, 100);
        }
      });
    }

    // Strategy 4: ResizeObserver for ongoing size changes
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        if (entry.contentRect.width > 0 && entry.contentRect.height > 0) {
          console.log("ResizeObserver: Container resized, calling invalidateSize");
          mapInstance.invalidateSize();
        }
      }
    });

    resizeObserver.observe(mapContainerRef.current);

    // Strategy 5: Intersection Observer to detect when map becomes visible
    const intersectionObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting && entry.intersectionRect.width > 0 && entry.intersectionRect.height > 0) {
          console.log("Map container became fully visible, calling invalidateSize");
          setTimeout(() => mapInstance.invalidateSize(), 50);
        }
      });
    }, { threshold: [0.1, 0.5, 1.0] }); // Multiple thresholds

    intersectionObserver.observe(mapContainerRef.current);

    // Cleanup
    return () => {
      resizeObserver.disconnect();
      intersectionObserver.disconnect();
    };
  }, [mapInstance]);

  // Additional effect to handle scroll and window events
  useEffect(() => {
    if (!mapInstance) return;

    const handleViewportChange = () => {
      clearTimeout(window.mapInvalidateTimeout);
      window.mapInvalidateTimeout = setTimeout(() => {
        if (mapContainerRef.current) {
          const rect = mapContainerRef.current.getBoundingClientRect();
          if (rect.width > 0 && rect.height > 0) {
            console.log("Viewport change detected, calling invalidateSize");
            mapInstance.invalidateSize();
          }
        }
      }, 100);
    };

    window.addEventListener('resize', handleViewportChange);
    window.addEventListener('scroll', handleViewportChange);
    
    return () => {
      window.removeEventListener('resize', handleViewportChange);
      window.removeEventListener('scroll', handleViewportChange);
      clearTimeout(window.mapInvalidateTimeout);
    };
  }, [mapInstance]);
  
  const handlePoiClick = (poi) => {
    setSelectedPoi(poi);
  };

  const handleEncounterClick = async (encounter) => {
    const distance = calculateDistance(
      playerLocation?.latitude,
      playerLocation?.longitude,
      encounter.latitude,
      encounter.longitude
    );

    if (distance > INTERACTION_RADIUS_METERS) {
      setNotification({
        isOpen: true,
        title: "Too Far Away",
        message: `You must be within ${INTERACTION_RADIUS_METERS} meters to interact. You are currently ${Math.round(distance)}m away.`,
        icon: <AlertTriangle className="w-8 h-8 text-orange-400" />
      });
      return;
    }
    
    if (encounter.expires_at && new Date(encounter.expires_at) < new Date()) {
      setNotification({
        isOpen: true,
        title: "Encounter Expired",
        message: "This encounter has already expired and disappeared.",
        icon: <Timer className="w-8 h-8 text-gray-400" />
      });
      // FIX: Add debugging and safer encounter removal
      console.log(`Removing expired encounter ${encounter.id} from encounters list`);
      console.log(`Current encounters before removal:`, encounters.map(e => ({ id: e.id, type: e.encounter_type })));
      setEncounters(prev => {
        const filtered = prev.filter(e => e.id !== encounter.id);
        console.log(`Encounters after removing expired encounter:`, filtered.map(e => ({ id: e.id, type: e.encounter_type })));
        return filtered;
      });
      return;
    }

    if (encounter.encounter_type === "monster") {
      if (!contextUserStats) {
        setNotification({
          isOpen: true,
          title: "Loading...",
          message: "User data is still loading, please try again in a moment.",
          icon: <AlertTriangle className="w-8 h-8 text-orange-400" />
        });
        return;
      }
      const userLevel = contextUserStats.level || 1;

      const appropriateMonsters = monsters.filter(monster =>
        userLevel >= monster.min_level && 
        userLevel <= monster.max_level
      );

      console.log(`Player is level ${userLevel}. Found ${appropriateMonsters.length} appropriate monsters.`);

      if (appropriateMonsters.length > 0) {
        const randomMonster = appropriateMonsters[Math.floor(Math.random() * appropriateMonsters.length)];
        setEncounterMonster(randomMonster);
        setActiveEncounter(encounter);
      } else {
        setNotification({
          isOpen: true,
          title: "No Danger Here",
          message: `No monsters appropriate for your level (${userLevel}) were found at this encounter site.`,
          icon: <CheckCircle className="w-8 h-8 text-green-400" />
        });
      }
    } else if (encounter.encounter_type === "treasure") {
      const goldFound = Math.floor(Math.random() * 100) + 25;
      try {
        console.log(`Treasure encounter: awarding ${goldFound} gold to user`);
        
        const newCoinTotal = (contextUserStats.coins ?? 0) + goldFound;
        const { data: updatedUser } = await updateUserData({
          coins: newCoinTotal
        });
        
        console.log(`Updated user coins from ${contextUserStats.coins} to ${newCoinTotal}`);
        
        setContextUserStats(updatedUser);
        setLocalUserStats(updatedUser);
        
        // FIX: Add debugging and safer encounter removal for treasure
        console.log(`Attempting to delete treasure encounter with id: ${encounter.id}`);
        console.log(`Current encounters before treasure removal:`, encounters.map(e => ({ id: e.id, type: e.encounter_type })));
        
        const deleteResult = await deleteRandomEncounter({ id: encounter.id });
        console.log(`Delete result:`, deleteResult);
        
        // FIX: Use functional update with debugging to ensure we only remove the correct encounter
        setEncounters(prev => {
          const originalCount = prev.length;
          const filtered = prev.filter(e => e.id !== encounter.id);
          console.log(`Encounters before treasure removal: ${originalCount}, after removal: ${filtered.length}`);
          console.log(`Removed encounter ID: ${encounter.id}, remaining encounters:`, filtered.map(e => ({ id: e.id, type: e.encounter_type })));
          return filtered;
        });

        setNotification({
          isOpen: true,
          title: "Treasure Found!",
          message: `You discovered a hidden chest and gained ${goldFound} gold coins!`,
          icon: <Coins className="w-8 h-8 text-yellow-400" />
        });
      } catch (error) {
        console.error("Error handling treasure:", error);
        setNotification({
          isOpen: true,
          title: "Error",
          message: "Something went wrong while collecting the treasure. Please try again.",
          icon: <AlertTriangle className="w-8 h-8 text-red-400" />
        });
      }
    }
  };

  const handleMonsterDefeat = async (victory, monster) => {
    if (victory) {
      const goldReward = monster.gold_reward || 0;
      const newCoinTotal = (contextUserStats.coins ?? 0) + goldReward;

      setContextUserStats(prevStats => ({
        ...prevStats,
        coins: newCoinTotal
      }));
      setLocalUserStats(prevStats => ({
        ...prevStats,
        coins: newCoinTotal
      }));
      
      try {
        console.log("Attempting to add monster to compendium:", {
          monster_id: monster.id,
          encounter_type: 'victory',
          gold_earned: goldReward,
          encounter_date: new Date().toISOString()
        });
        
        const result = await createPlayerEncounter({
          monster_id: monster.id,
          encounter_type: 'victory',
          gold_earned: goldReward,
          encounter_date: new Date().toISOString(),
          location_latitude: playerLocation?.latitude,
          location_longitude: playerLocation?.longitude
        });
        
        console.log("Monster compendium result:", result);
        
        if (result.data && (result.data.success || result.data.id)) {
          console.log("✅ Monster added to compendium successfully");
        } else {
          console.warn("⚠️ Monster compendium call completed but may not have succeeded:", result);
        }
        
      } catch (error) {
        console.error("❌ Error adding monster to compendium:", error);
        console.log("Continuing with victory despite compendium error...");
      }
      
      setNotification({
        isOpen: true,
        title: "Victory!",
        message: `You defeated the ${monster.name} and gained ${goldReward} gold!`,
        icon: <Swords className="w-8 h-8 text-green-400" />
      });

      try {
        await updateUserData({
          coins: newCoinTotal
        });
      } catch (error) {
        console.error("Error updating coins after monster defeat:", error);
      }
    } else {
      setNotification({
        isOpen: true,
        title: "You Fled",
        message: "You managed to escape from the monster. The encounter has disappeared.",
        icon: <Shield className="w-8 h-8 text-blue-400" />
      });
    }

    // FIX: Remove only the specific encounter and reload if needed
    if (activeEncounter) {
      try {
        console.log(`Attempting to delete monster encounter with id: ${activeEncounter.id}`);
        
        await deleteRandomEncounter({ id: activeEncounter.id });
        
        // FIX: Use functional update that preserves other encounters
        setEncounters(prevEncounters => {
          const newEncounters = prevEncounters.filter(e => e.id !== activeEncounter.id);
          console.log(`Encounters after removing monster ${activeEncounter.id}:`, newEncounters.length);
          
          // FIX: If we're down to 1 or 0 encounters, reload them
          if (newEncounters.length <= 1 && playerLocation && isTrackingLocation) {
            setTimeout(() => {
              console.log("🔄 Low encounter count, triggering reload...");
              // Use the GPS service to reload encounters
              if (window.gpsService && window.gpsService.reloadEncounters) {
                window.gpsService.reloadEncounters(playerLocation.latitude, playerLocation.longitude);
              }
            }, 1000);
          }
          
          return newEncounters;
        });
      } catch (error) {
        console.error("Error removing encounter:", error);
      }
    }

    setActiveEncounter(null);
    setEncounterMonster(null);
  };

  const handleVisitLocation = async (poi) => {
    const distance = calculateDistance(
      playerLocation?.latitude,
      playerLocation?.longitude,
      poi.latitude,
      poi.longitude
    );

    if (distance > INTERACTION_RADIUS_METERS) {
      setNotification({
        isOpen: true,
        title: "Too Far Away",
        message: `You must be within ${INTERACTION_RADIUS_METERS} meters to visit ${poi.name}. You are currently ${Math.round(distance)}m away.`,
        icon: <AlertTriangle className="w-8 h-8 text-orange-400" />
      });
      return;
    }
    
    if (contextUserStats.total_steps >= poi.steps_required) {
      try {
        const visitedLocations = Array.isArray(contextUserStats.visited_locations) ? contextUserStats.visited_locations : [];
        if (!visitedLocations.includes(poi.id)) {
          const { data: updatedUser } = await updateUserData({
            visited_locations: JSON.stringify([...visitedLocations, poi.id]),
            coins: (contextUserStats.coins ?? 0) + poi.coin_reward
          });
          
          // FIX: The `updatedUser.visited_locations` is already a parsed array from the server.
          // There is no need to call JSON.parse() on it again.
          // The `updatedUser` object can be used directly.

          setContextUserStats(updatedUser);
          setLocalUserStats(updatedUser);

          setNotification({
            isOpen: true,
            title: "Location Visited!",
            message: `You successfully visited ${poi.name} and gained ${poi.coin_reward} gold!`,
            icon: <CheckCircle className="w-8 h-8 text-green-400" />
          });
        } else {
          setNotification({
            isOpen: true,
            title: "Already Visited",
            message: `You have already explored ${poi.name}.`,
            icon: <CheckCircle className="w-8 h-8 text-green-400" />
          });
        }
      } catch (error) {
        console.error("Error visiting location:", error);
        setNotification({
          isOpen: true,
          title: "Error",
          message: "Failed to visit location. Please try again.",
          icon: <AlertTriangle className="w-8 h-8 text-red-400" />
        });
      }
    } else {
      setNotification({
        isOpen: true,
        title: "Steps Required",
        message: `You need ${poi.steps_required.toLocaleString()} steps to visit ${poi.name}. You currently have ${contextUserStats?.total_steps?.toLocaleString() || 0} steps.`,
        icon: <Lock className="w-8 h-8 text-gray-400" />
      });
    }
  };

  const isLocationVisited = (poiId) => {
    return contextUserStats?.visited_locations?.includes(poiId) || false;
  };

  const canVisitLocation = (poi) => {
    return (contextUserStats?.total_steps || 0) >= poi.steps_required;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-stone-900 to-amber-900 flex items-center justify-center">
        <div className="text-amber-100 text-lg">Loading the map of Tel Aviv University...</div>
      </div>
    );
  }

  if (mapError) {
     return (
      <div className="min-h-screen bg-gradient-to-br from-red-900 to-black flex items-center justify-center p-4 text-center">
        <div>
          <h2 className="text-2xl font-bold text-red-300 mb-2">Map Error</h2>
          <p className="text-red-200">{mapError}</p>
        </div>
      </div>
    );
  }

  if (!mapKey) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-stone-900 to-amber-900 flex items-center justify-center">
        <div className="text-amber-100 text-lg">Map key not available...</div>
      </div>
    );
  }

  const azureMapsUrl = `https://atlas.microsoft.com/map/tile?api-version=2.0&tilesetId=microsoft.imagery&zoom={z}&x={x}&y={y}&subscription-key=${mapKey}`;
  const azureMapsAttribution = '© Microsoft Azure Maps';
  
  console.log("Constructed Azure Maps URL template:", azureMapsUrl.replace(mapKey, "REDACTED_KEY"));

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-900 to-amber-900 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-amber-100 mb-2">
            Map of Tel Aviv University
          </h1>
          <p className="text-amber-300/70">
            Explore the campus and discover its secrets. Click on markers to interact!
          </p>
          
          {/* NEW: Important GPS Instructions */}
          <div className="mt-4 p-4 bg-blue-900/20 border border-blue-600/30 rounded-lg">
            <div className="flex items-start gap-3">
              <div className="text-blue-400 mt-1">
                <Navigation className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-blue-300 font-medium mb-2">📍 GPS Adventure Instructions</h3>
                <ul className="text-blue-200 text-sm space-y-1">
                  <li>• <strong>Stay on this Map page</strong> during your entire adventure</li>
                  <li>• Steps are only saved when you properly <strong>"Stop GPS"</strong></li>
                  <li>• Switching pages will lose your current session progress</li>
                  <li>• Walk to nearby encounters before they expire!</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3">
            <Card className="fantasy-border bg-stone-800/90 backdrop-blur-sm overflow-hidden">
              <CardContent className="p-0">
                <div className="h-96 md:h-[600px] relative" ref={mapContainerRef}>
                  <MapContainer
                    center={TAU_CENTER}
                    zoom={16}
                    style={{ height: "100%", width: "100%" }}
                    className="rounded-lg"
                    maxBounds={[
                      [31.900, 34.600],
                      [32.500, 35.200]
                    ]}
                    maxBoundsViscosity={0.2}
                    whenCreated={(map) => {
                      console.log("Map created, setting instance...");
                      setMapInstance(map);
                    }}
                  >
                    <TileLayer
                      url={azureMapsUrl}
                      attribution={azureMapsAttribution}
                      maxZoom={18}
                      minZoom={14}
                      errorTileUrl="data:image/png;base64,iVBORw0goAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQIHQEAIAAAxfSAyIAAAAAASUVORK5CYII="
                      onError={(error) => {
                        console.error("TileLayer error:", error);
                      }}
                      onLoad={() => {
                        console.log("TileLayer loaded successfully");
                      }}
                      onTileLoadStart={(e) => {
                        console.log("Tile loading started:", e.coords);
                      }}
                      onTileLoad={(e) => {
                        console.log("Tile loaded successfully:", e.coords);
                      }}
                      onTileError={(e) => {
                        console.error("Tile failed to load:", e.coords, e.error);
                      }}
                    />
                    
                    {playerLocation && (
                      <>
                        <Marker
                          position={[playerLocation.latitude, playerLocation.longitude]}
                          icon={playerIcon}
                        >
                          <Popup autoPan={false} closeOnEscapeKey={true}>
                            <PlayerPopupContent 
                              playerLocation={playerLocation}
                              locationAccuracy={locationAccuracy}
                            />
                          </Popup>
                        </Marker>
                        
                        {locationAccuracy && (
                          <Circle
                            center={[playerLocation.latitude, playerLocation.longitude]}
                            radius={locationAccuracy}
                            pathOptions={{
                              color: '#3b82f6',
                              fillColor: '#3b82f6',
                              fillOpacity: 0.1,
                              weight: 2
                            }}
                          />
                        )}
                      </>
                    )}
                    
                    {pois.map((poi) => (
                      <Marker
                        key={poi.id}
                        position={[poi.latitude, poi.longitude]}
                        icon={isLocationVisited(poi.id) ? visitedIcon : poiIcon}
                        eventHandlers={{
                          click: (e) => {
                            // Prevent map zoom on marker click
                            e.originalEvent.stopPropagation();
                            handlePoiClick(poi);
                          },
                        }}
                      >
                        <Popup autoPan={false} closeOnEscapeKey={true}>
                          <PoiPopupContent poi={poi} isVisited={isLocationVisited(poi.id)} />
                        </Popup>
                      </Marker>
                    ))}

                    {/* FIX: Add safety check to ensure encounters is always an array */}
                    {Array.isArray(encounters) && encounters.map((encounter) => (
                      <Marker
                        key={encounter.id}
                        position={[encounter.latitude, encounter.longitude]}
                        icon={encounter.encounter_type === "treasure" ? treasureIcon : encounterIcon}
                        eventHandlers={{
                          click: (e) => {
                            // Prevent map zoom on marker click
                            e.originalEvent.stopPropagation();
                            handleEncounterClick(encounter);
                          },
                        }}
                      >
                        <Popup autoPan={false} closeOnEscapeKey={true}>
                          <EncounterPopupContent encounter={encounter} />
                        </Popup>
                      </Marker>
                    ))}
                  </MapContainer>
                  
                  <div className="absolute top-4 right-4 space-y-2 z-[1000]">
                    <Button
                      onClick={() => {
                        if (isTrackingLocation) {
                          handleStopGPS();
                        } else {
                          handleStartGPS();
                        }
                      }}
                      className={`${
                        isTrackingLocation 
                          ? 'bg-red-600 hover:bg-red-700' 
                          : 'bg-blue-600 hover:bg-blue-700'
                      } text-white shadow-lg`}
                      size="sm"
                    >
                      <Navigation className="w-4 h-4 mr-2" />
                      {isTrackingLocation ? 'Stop GPS' : 'Start GPS'}
                    </Button>
                    
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="fantasy-border bg-gradient-to-br from-orange-900/30 to-yellow-900/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-amber-100">
                  <Navigation className="w-6 h-6 text-orange-400" />
                  Location Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-center">
                  <div className={`text-lg font-bold ${isTrackingLocation ? 'text-green-400' : 'text-gray-400'}`}>
                    {isTrackingLocation ? '🟢 GPS Active' : '🔴 GPS Inactive'}
                  </div>
                  <div className="text-sm text-amber-300/70">
                    {playerLocation ? 'Location detected' : 'No location data'}
                  </div>
                </div>
                
                {playerLocation && isTrackingLocation && (
                  <div className="space-y-2 text-xs text-amber-200">
                    <div className="flex justify-between">
                      <span>Accuracy:</span>
                      <span>±{Math.round(locationAccuracy || 0)}m</span>
                    </div>
                    <div className="flex justify-between items-center border-t border-amber-500/10 pt-2 mt-2">
                       <span className="flex items-center gap-1"><Footprints className="w-3 h-3 text-amber-400" /> Adventure Steps:</span>
                       <span className="font-bold text-amber-100">{Math.round(sessionSteps || 0)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Active Encounters:</span>
                      <span>{encounters.length}</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="fantasy-border bg-gradient-to-br from-blue-900/30 to-indigo-900/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-amber-100">
                  <MapPin className="w-6 h-6 text-blue-400" />
                  Campus Locations
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 max-h-96 overflow-y-auto">
                {pois.map((poi) => (
                  <div
                    key={poi.id}
                    className={`p-3 rounded-lg border cursor-pointer transition-all duration-300 ${ 
                      isLocationVisited(poi.id)
                        ? 'bg-green-900/20 border-green-600/30'
                        : canVisitLocation(poi)
                        ? 'bg-blue-900/20 border-blue-600/30 hover:bg-blue-900/30'
                        : 'bg-gray-900/20 border-gray-600/30'
                    } ${selectedPoi?.id === poi.id ? 'ring-2 ring-amber-500' : ''}`}
                    onClick={() => handlePoiClick(poi)}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-medium text-amber-100 text-sm">{poi.name}</h4>
                      {isLocationVisited(poi.id) ? (
                        <CheckCircle className="w-4 h-4 text-green-400" />
                      ) : !canVisitLocation(poi) ? (
                        <Lock className="w-4 h-4 text-gray-400" />
                      ) : (
                        <Badge variant="outline" className="text-xs">
                          <Coins className="w-3 h-3 mr-1" />
                          {poi.coin_reward}
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-amber-300/70">{poi.description}</p>
                    <div className="text-xs text-amber-300/50 mt-1">
                      Requires: {poi.steps_required.toLocaleString()} steps
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {selectedPoi && (
              <Card className="fantasy-border bg-gradient-to-br from-purple-900/30 to-pink-900/30 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-amber-100">{selectedPoi.name}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-amber-300/80 text-sm">{selectedPoi.description}</p>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-amber-200">Region:</span>
                      <span className="text-amber-100">{selectedPoi.region}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-amber-200">Type:</span>
                      <span className="text-amber-100 capitalize">{selectedPoi.location_type}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-amber-200">Reward:</span>
                      <span className="text-amber-100 flex items-center gap-1">
                        <Coins className="w-3 h-3" />
                        {selectedPoi.coin_reward} Gold
                      </span>
                    </div>
                  </div>

                  <Button
                    onClick={() => handleVisitLocation(selectedPoi)}
                    disabled={!canVisitLocation(selectedPoi) || isLocationVisited(selectedPoi.id)}
                    className={`w-full ${
                      isLocationVisited(selectedPoi.id)
                        ? 'bg-green-600 hover:bg-green-700'
                        : canVisitLocation(selectedPoi)
                        ? 'bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-700 hover:to-yellow-700'
                        : 'bg-gray-600'
                    } text-stone-900 font-bold`}
                  >
                    {isLocationVisited(selectedPoi.id) ? (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Visited
                      </>
                    ) : canVisitLocation(selectedPoi) ? (
                      <>
                        <MapPin className="w-4 h-4 mr-2" />
                        Visit Location
                      </>
                    ) : (
                      <>
                        <Lock className="w-4 h-4 mr-2" />
                        {selectedPoi.steps_required.toLocaleString()} steps required
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      {activeEncounter && encounterMonster && (
        <MonsterEncounter
          monster={encounterMonster}
          userLevel={contextUserStats?.level || 1}
          onComplete={handleMonsterDefeat}
          onFlee={() => {
            handleMonsterDefeat(false, encounterMonster);
          }}
        />
      )}

      <AnimatePresence>
        {notification.isOpen && (
          <InfoModal
            title={notification.title}
            message={notification.message}
            icon={notification.icon}
            onClose={() => setNotification({ isOpen: false, title: '', message: '', icon: null })}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
