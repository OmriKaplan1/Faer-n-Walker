
import React, { useState, useEffect } from "react";
import { getInventory } from "@/api/functions";
import { equipItem } from "@/api/functions";
import { unequipItem } from "@/api/functions";
import { useItem } from "@/api/functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Package, Shield, Sword, Star, Zap, Info } from "lucide-react";
import InventoryItem from "../components/inventory/InventoryItem";

export default function Inventory() {
  const [inventory, setInventory] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadInventory();
  }, []);

  const loadInventory = async () => {
    setIsLoading(true);
    try {
      const { data } = await getInventory();
      setInventory(data || []);
    } catch (error) {
      console.error("Error loading inventory:", error);
      setInventory([]);
    }
    setIsLoading(false);
  };

  const handleEquip = async (itemToEquip) => {
    try {
      await equipItem({ userEquipmentId: itemToEquip.user_equipment_id });
      // Refresh inventory to show equipped status change
      loadInventory(); 
    } catch (error) {
      console.error("Error equipping item:", error);
    }
  };
  
  const handleUnequip = async (itemToUnequip) => {
    try {
      await unequipItem({ userEquipmentId: itemToUnequip.user_equipment_id });
      loadInventory();
    } catch (error) {
      console.error("Error unequipping item:", error);
    }
  };

  const handleUse = async (itemToUse) => {
    try {
      await useItem({ userEquipmentId: itemToUse.user_equipment_id });
      // Refresh inventory to show quantity change or removal
      loadInventory();
    } catch (error) {
      console.error("Error using item:", error);
    }
  };

  const filterInventory = (type) => {
    return inventory.filter(item => item.type === type);
  };

  const equippedItems = inventory.filter(item => item.is_equipped);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-stone-900 to-amber-900 flex items-center justify-center">
        <div className="text-amber-100 text-lg">Loading your inventory...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-900 to-amber-900 p-2 sm:p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6 md:mb-8">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-amber-100 mb-2">
            Inventory
          </h1>
          <p className="text-amber-300/70 text-sm sm:text-base">
            Manage your equipment and use your items.
          </p>
        </div>

        {inventory.length === 0 ? (
           <Card className="fantasy-border bg-stone-800/80 p-8 text-center">
            <Info className="w-12 h-12 mx-auto text-amber-400 mb-4" />
            <h3 className="text-xl font-bold text-amber-100">Your pack is empty!</h3>
            <p className="text-amber-300/70">Visit the Shop to purchase equipment and consumables.</p>
          </Card>
        ) : (
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Tabs defaultValue="all" className="space-y-4">
                <TabsList className="bg-stone-800/50 p-1">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="weapon">Weapons</TabsTrigger>
                  <TabsTrigger value="armor">Armor</TabsTrigger>
                  <TabsTrigger value="accessory">Accessories</TabsTrigger>
                  <TabsTrigger value="consumable">Consumables</TabsTrigger>
                </TabsList>
                
                <TabsContent value="all" className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {inventory.map(item => <InventoryItem key={item.user_equipment_id} item={item} onEquip={handleEquip} onUnequip={handleUnequip} onUse={handleUse} />)}
                </TabsContent>
                <TabsContent value="weapon" className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filterInventory('weapon').map(item => <InventoryItem key={item.user_equipment_id} item={item} onEquip={handleEquip} onUnequip={handleUnequip} />)}
                </TabsContent>
                <TabsContent value="armor" className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filterInventory('armor').map(item => <InventoryItem key={item.user_equipment_id} item={item} onEquip={handleEquip} onUnequip={handleUnequip} />)}
                </TabsContent>
                <TabsContent value="accessory" className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filterInventory('accessory').map(item => <InventoryItem key={item.user_equipment_id} item={item} onEquip={handleEquip} onUnequip={handleUnequip} />)}
                </TabsContent>
                <TabsContent value="consumable" className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filterInventory('consumable').map(item => <InventoryItem key={item.user_equipment_id} item={item} onUse={handleUse} />)}
                </TabsContent>
              </Tabs>
            </div>
            
            <div className="space-y-6">
              <Card className="fantasy-border bg-gradient-to-br from-blue-900/30 to-indigo-900/30 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-amber-100">
                    <Shield className="w-6 h-6 text-blue-400" />
                    Equipped Items
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {equippedItems.length > 0 ? (
                    equippedItems.map(item => (
                      <InventoryItem key={item.user_equipment_id} item={item} onEquip={handleEquip} onUnequip={handleUnequip} />
                    ))
                  ) : (
                    <p className="text-amber-300/70 text-center py-4">No items equipped.</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
