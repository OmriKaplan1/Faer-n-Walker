
import React, { useState, useEffect } from 'react';
import { getCompendium } from '@/api/functions';
import { listMonsters } from '@/api/functions';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Swords, Shield, Skull, HelpCircle, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const MonsterModal = ({ monster, onClose }) => {
  // FIX: Better error handling for monster images
  const getMonsterImageUrl = (monsterName) => {
    return `https://zoosync2.blob.core.windows.net/reportphoto/${monsterName}.jpg`;
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.8 }}
        className="max-w-2xl w-full"
      >
        <Card className="fantasy-border bg-gradient-to-br from-stone-800/95 to-amber-900/90 backdrop-blur-sm">
          <CardHeader className="flex flex-row items-start justify-between">
            <div className="flex-1">
              <CardTitle className="text-2xl text-amber-100">{monster.name}</CardTitle>
              <Badge variant="outline" className="mt-2">CR {monster.challenge_rating}</Badge>
            </div>
            <button
              onClick={onClose}
              className="text-amber-300 hover:text-amber-100 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="w-full h-64 rounded-lg overflow-hidden bg-black/50">
              <img 
                src={getMonsterImageUrl(monster.name)} 
                alt={monster.name}
                className="w-full h-full object-contain"
                onError={(e) => {
                  console.log(`❌ Failed to load image for ${monster.name}, using placeholder`);
                  e.target.src = `https://via.placeholder.com/400x300/8B4513/FFFFFF?text=${encodeURIComponent(monster.name)}`;
                }}
                onLoad={() => {
                  console.log(`✅ Successfully loaded image for ${monster.name}`);
                }}
              />
            </div>
            
            <p className="text-amber-300/80 text-sm leading-relaxed">
              {monster.description}
            </p>
            
            <div className="border-t border-amber-700/30 pt-4">
              <h4 className="font-semibold text-amber-200 mb-3">Encounter Statistics</h4>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div className="flex items-center gap-2 p-2 rounded bg-stone-700/30">
                  <Swords className="w-4 h-4 text-green-400" />
                  <div>
                    <div className="font-medium text-slate-200">Victories</div>
                    <div className="text-green-400">{monster.encounter_stats.victories}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 p-2 rounded bg-stone-700/30">
                  <Shield className="w-4 h-4 text-blue-400" />
                  <div>
                    <div className="font-medium text-slate-200">Fled</div>
                    <div className="text-blue-400">{monster.encounter_stats.fled}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 p-2 rounded bg-stone-700/30">
                  <Skull className="w-4 h-4 text-red-400" />
                  <div>
                    <div className="font-medium text-slate-200">Defeats</div>
                    <div className="text-red-400">{monster.encounter_stats.defeats}</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

const MonsterCard = ({ monster, isDiscovered, onClick }) => {
  // FIX: Same error handling for monster card images
  const getMonsterImageUrl = (monsterName) => {
    return `https://zoosync2.blob.core.windows.net/reportphoto/${monsterName}.jpg`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="cursor-pointer"
      onClick={onClick}
    >
      <Card className="fantasy-border bg-stone-800/80 backdrop-blur-sm hover:bg-stone-700/80 transition-all duration-300 aspect-square">
        <CardContent className="p-0 h-full flex items-center justify-center">
          {isDiscovered ? (
            <div className="w-full h-full relative overflow-hidden rounded-lg bg-black/30">
              <img 
                src={getMonsterImageUrl(monster.name)} 
                alt={monster.name}
                className="w-full h-full object-contain"
                onError={(e) => {
                  console.log(`❌ Failed to load thumbnail for ${monster.name}, using placeholder`);
                  e.target.src = `https://via.placeholder.com/200x200/8B4513/FFFFFF?text=${encodeURIComponent(monster.name)}`;
                }}
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-2">
                <h3 className="text-white font-medium text-sm truncate">{monster.name}</h3>
                <Badge variant="outline" className="text-xs border-amber-600/50 text-amber-300">
                  CR {monster.challenge_rating}
                </Badge>
              </div>
            </div>
          ) : (
            <div className="text-center p-4">
              <HelpCircle className="w-12 h-12 text-stone-400 mx-auto mb-2" />
              <p className="text-stone-400 text-sm">Undiscovered</p>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default function Compendium() {
  const [compendium, setCompendium] = useState([]);
  const [allMonsters, setAllMonsters] = useState([]);
  const [selectedMonster, setSelectedMonster] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [compendiumRes, monstersRes] = await Promise.all([
          getCompendium(),
          listMonsters()
        ]);
        
        // FIX: De-duplicate by monster NAME instead of ID to handle same monsters with different IDs
        const uniqueAllMonsters = Array.from(new Map((monstersRes.data || []).map(item => [item.name, item])).values());
        const uniqueCompendium = Array.from(new Map((compendiumRes.data.compendium || []).map(item => [item.name, item])).values());

        console.log(`Original monsters: ${monstersRes.data?.length}, Unique by name: ${uniqueAllMonsters.length}`);
        console.log(`Original compendium: ${compendiumRes.data.compendium?.length}, Unique by name: ${uniqueCompendium.length}`);

        // Also log the names to see what we have
        console.log(`Monster names:`, uniqueAllMonsters.map(m => m.name));
        console.log(`Compendium monster names:`, uniqueCompendium.map(m => m.name));

        setCompendium(uniqueCompendium);
        setAllMonsters(uniqueAllMonsters);
      } catch (error) {
        console.error("Failed to load compendium data:", error);
      }
      setIsLoading(false);
    };

    loadData();
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-stone-900 to-amber-900 flex items-center justify-center">
        <div className="text-amber-100 text-lg">Loading Monster Compendium...</div>
      </div>
    );
  }

  // FIX: Use monster names as the key for discovered check instead of IDs
  const discoveredMonsterNames = new Set(compendium.map(m => m.name));
  const discoveredCount = discoveredMonsterNames.size;
  const totalCount = allMonsters.length;

  const handleMonsterClick = (monster, isDiscovered) => {
    if (isDiscovered) {
      setSelectedMonster(monster);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-900 to-amber-900 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-amber-100 mb-2 flex items-center gap-3">
            <BookOpen className="w-8 h-8" />
            Monster Compendium
          </h1>
          <p className="text-amber-300/70 mb-4">
            A collection of creatures you have encountered on your journeys.
          </p>
          <div className="flex items-center gap-4">
            <Badge className="bg-amber-600/20 text-amber-200 border-amber-600/30">
              {discoveredCount} of {totalCount} discovered
            </Badge>
            <div className="flex-1 bg-stone-700/50 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-amber-600 to-yellow-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${totalCount > 0 ? (discoveredCount / totalCount) * 100 : 0}%` }}
              />
            </div>
          </div>
        </div>

        {totalCount > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {allMonsters.map((monster) => {
              const isDiscovered = discoveredMonsterNames.has(monster.name);
              // When a monster is discovered, we use the full data from the compendium
              // which should ideally contain all details needed for the modal.
              // If not discovered, we use the basic data from allMonsters list.
              // The `monster` prop passed to MonsterCard and MonsterModal must contain `name`.
              // For discovered monsters, `compendium.find` provides the full object.
              // For undiscovered, `monster` from `allMonsters` is used, which definitely has `name` and `id`.
              const monsterDataForCard = isDiscovered 
                ? compendium.find(m => m.name === monster.name) 
                : monster;
              
              return (
                <MonsterCard
                  key={monster.name} // Use name as key instead of ID
                  monster={monsterDataForCard || monster} // Fallback to monster if compendium data is weird
                  isDiscovered={isDiscovered}
                  onClick={() => handleMonsterClick(monsterDataForCard || monster, isDiscovered)}
                />
              );
            })}
          </div>
        ) : (
          <Card className="fantasy-border bg-stone-800/80 p-8 text-center">
            <h3 className="text-xl font-bold text-amber-100">No monsters found.</h3>
            <p className="text-amber-300/70">The compendium appears to be empty.</p>
          </Card>
        )}
      </div>

      <AnimatePresence>
        {selectedMonster && (
          <MonsterModal 
            monster={selectedMonster} 
            onClose={() => setSelectedMonster(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}
