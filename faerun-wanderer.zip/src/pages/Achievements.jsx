import React, { useState, useEffect } from "react";
import { listAchievements } from "@/api/functions";
import { listUserAchievements } from "@/api/functions";
import { getUserData } from "@/api/functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Trophy, Star, Crown, Gem, Coins, Lock } from "lucide-react";
import { motion } from "framer-motion";

export default function Achievements() {
  const [achievements, setAchievements] = useState([]);
  const [userAchievements, setUserAchievements] = useState([]);
  const [userStats, setUserStats] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [achievementsRes, userAchievementsRes, userRes] = await Promise.all([
        listAchievements(),
        listUserAchievements(),
        getUserData()
      ]);
      
      console.log("🏆 Raw achievements data:", achievementsRes.data);
      console.log("🎯 Raw user achievements data:", userAchievementsRes.data);
      
      // Parse visited_locations if it's a JSON string
      let visitedLocations = [];
      if (userRes.data.visited_locations) {
        if (Array.isArray(userRes.data.visited_locations)) {
          visitedLocations = userRes.data.visited_locations;
        } else if (typeof userRes.data.visited_locations === 'string') {
          try {
            visitedLocations = JSON.parse(userRes.data.visited_locations);
          } catch (e) {
            console.error("Could not parse visited_locations:", userRes.data.visited_locations);
            visitedLocations = [];
          }
        }
      }
      
      const processedUserStats = {
        ...userRes.data,
        visited_locations: visitedLocations
      };
      
      setAchievements(achievementsRes.data || []);
      setUserAchievements(userAchievementsRes.data || []);
      setUserStats(processedUserStats);
      
      console.log("📊 Processed achievements:", achievementsRes.data?.length || 0);
      console.log("🎖️ Processed user achievements:", userAchievementsRes.data?.length || 0);
      
    } catch (error) {
      console.error("Error loading achievements:", error);
    }
    setIsLoading(false);
  };

  const getRarityIcon = (rarity) => {
    switch (rarity) {
      case "legendary": return Crown;
      case "epic": return Gem;
      case "rare": return Star;
      default: return Trophy;
    }
  };

  const getRarityColor = (rarity) => {
    switch (rarity) {
      case "legendary": return "from-yellow-400 to-amber-600";
      case "epic": return "from-purple-400 to-pink-600";
      case "rare": return "from-blue-400 to-cyan-600";
      case "uncommon": return "from-green-400 to-emerald-600";
      default: return "from-gray-400 to-slate-600";
    }
  };

  // **FIX: Improved achievement matching logic**
  const isAchievementUnlocked = (achievement) => {
    // Try multiple ways to match achievements
    const isUnlocked = userAchievements.some(ua => {
      // Method 1: Match by achievement_id (if it exists and matches)
      if (ua.achievement_id === achievement.id) {
        console.log(`✅ Achievement "${achievement.title}" matched by ID: ${achievement.id}`);
        return ua.unlocked_date; // Only count if unlocked_date exists
      }
      
      // Method 2: Match by title (fallback method)
      if (ua.achievement_title === achievement.title || ua.title === achievement.title) {
        console.log(`✅ Achievement "${achievement.title}" matched by title`);
        return ua.unlocked_date; // Only count if unlocked_date exists
      }
      
      return false;
    });
    
    if (!isUnlocked) {
      console.log(`❌ Achievement "${achievement.title}" not found in user achievements`);
    }
    
    return isUnlocked;
  };

  const getAchievementProgress = (achievement) => {
    const userAchievement = userAchievements.find(ua => 
      ua.achievement_id === achievement.id || 
      ua.achievement_title === achievement.title ||
      ua.title === achievement.title
    );
    
    switch (achievement.requirement_type) {
      case "daily_steps":
        return Math.min(userStats?.daily_steps || 0, achievement.requirement);
      case "total_steps":
        return Math.min(userStats?.total_steps || 0, achievement.requirement);
      case "locations_visited":
        return Math.min(userStats?.visited_locations?.length || 0, achievement.requirement);
      default:
        return userAchievement?.progress || 0;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-stone-900 to-amber-900 flex items-center justify-center">
        <div className="text-amber-100 text-lg">Loading achievements...</div>
      </div>
    );
  }

  // **FIX: Debug the calculation of unlocked achievements**
  const unlockedAchievements = achievements.filter(a => isAchievementUnlocked(a));
  console.log("🎯 Unlocked achievements:", unlockedAchievements.map(a => a.title));
  
  const unlockedCount = unlockedAchievements.length;
  const totalCoinsEarned = unlockedAchievements.reduce((sum, a) => sum + (a.coin_reward || 0), 0);

  console.log(`📈 Stats: ${unlockedCount} unlocked, ${totalCoinsEarned} gold earned`);

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-900 to-amber-900 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-amber-100 mb-2">
            Hall of Achievements
          </h1>
          <p className="text-amber-300/70">
            Your legendary deeds and accomplishments throughout Faerûn
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="fantasy-border bg-gradient-to-br from-amber-900/30 to-yellow-900/30 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <Trophy className="w-8 h-8 text-amber-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-amber-100">{unlockedCount}</div>
              <div className="text-sm text-amber-300/70">Achievements Unlocked</div>
            </CardContent>
          </Card>

          <Card className="fantasy-border bg-gradient-to-br from-green-900/30 to-emerald-900/30 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <Coins className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-amber-100">{totalCoinsEarned}</div>
              <div className="text-sm text-amber-300/70">Gold Earned</div>
            </CardContent>
          </Card>

          <Card className="fantasy-border bg-gradient-to-br from-purple-900/30 to-pink-900/30 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <Star className="w-8 h-8 text-purple-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-amber-100">
                {achievements.length > 0 ? Math.round((unlockedCount / achievements.length) * 100) : 0}%
              </div>
              <div className="text-sm text-amber-300/70">Completion Rate</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {achievements.map((achievement, index) => {
            const RarityIcon = getRarityIcon(achievement.rarity);
            const isUnlocked = isAchievementUnlocked(achievement);
            const progress = getAchievementProgress(achievement);
            const progressPercentage = (progress / achievement.requirement) * 100;

            return (
              <motion.div
                key={achievement.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className={`fantasy-border backdrop-blur-sm transition-all duration-300 hover:scale-105 ${
                  isUnlocked 
                    ? `bg-gradient-to-br ${getRarityColor(achievement.rarity)}/20 gold-glow` 
                    : 'bg-stone-800/50'
                }`}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${
                        isUnlocked 
                          ? `bg-gradient-to-br ${getRarityColor(achievement.rarity)} text-white`
                          : 'bg-stone-700 text-gray-400'
                      }`}>
                        {isUnlocked ? (
                          <RarityIcon className="w-6 h-6" />
                        ) : (
                          <Lock className="w-6 h-6" />
                        )}
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-amber-100 text-lg">
                          {achievement.title}
                        </CardTitle>
                        <Badge 
                          variant="outline" 
                          className={`text-xs mt-1 ${
                            isUnlocked 
                              ? 'border-amber-600/30 text-amber-300' 
                              : 'border-gray-600/30 text-gray-400'
                          }`}
                        >
                          {achievement.rarity || 'common'}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <p className="text-amber-300/80 text-sm">
                      {achievement.description}
                    </p>
                    
                    {!isUnlocked && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs text-amber-200">
                          <span>Progress</span>
                          <span>{progress.toLocaleString()}/{achievement.requirement.toLocaleString()}</span>
                        </div>
                        <Progress 
                          value={progressPercentage} 
                          className="h-2 bg-stone-700"
                        />
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1 text-amber-300">
                        <Coins className="w-4 h-4" />
                        <span className="font-medium">{achievement.coin_reward || 0} Gold</span>
                      </div>
                      {isUnlocked && (
                        <Badge className="bg-green-600 text-white">
                          Completed
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}