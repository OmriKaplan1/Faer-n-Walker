
import React, { useState, useEffect } from "react";
import { getUserData } from "@/api/functions";
import { updateUserData } from "@/api/functions";
import { getInventory } from "@/api/functions"; // NEW: Import getInventory
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Shield, Sword, Star, Heart, Zap, Coins, Edit, Save, Info, Axe, Skull, Wand, FlameKindling, Eye } from "lucide-react";
import { motion } from "framer-motion";

const CHARACTER_CLASSES = [
  { name: "Fighter", icon: Shield, color: "text-red-400" },
  { name: "Wizard", icon: Wand, color: "text-blue-400" },
  { name: "Rogue", icon: Sword, color: "text-green-400" },
  { name: "Cleric", icon: Heart, color: "text-yellow-400" },
  { name: "Ranger", icon: FlameKindling, color: "text-purple-400" },
  { name: "Paladin", icon: Shield, color: "text-amber-400" },
  { name: "Barbarian", icon: Axe, color: "text-orange-400" },
  { name: "Bard", icon: Star, color: "text-pink-400" },
  { name: "Sorcerer", icon: Zap, color: "text-indigo-400" },
  { name: "Warlock", icon: Skull, color: "text-purple-600" },
  { name: "Druid", icon: Heart, color: "text-green-600" },
  { name: "Monk", icon: Eye, color: "text-cyan-400" }
];

// NEW: Progressive level calculation function (same as Dashboard)
const calculateLevel = (totalSteps) => {
  let level = 1;
  let stepsRequiredForCurrentLevel = 0; // Steps required to reach current level from previous one
  
  while (true) {
    const stepsForNextLevel = level * 5000;
    if (totalSteps >= (stepsRequiredForCurrentLevel + stepsForNextLevel)) {
      stepsRequiredForCurrentLevel += stepsForNextLevel;
      level++;
    } else {
      break;
    }
  }
  
  return level;
};

export default function Character() {
  const [userStats, setUserStats] = useState(null);
  const [equippedItems, setEquippedItems] = useState([]); // NEW: State for equipped items
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    setIsLoading(true);
    try {
      const [userRes, inventoryRes] = await Promise.all([ // NEW: Fetch inventory too
        getUserData(),
        getInventory()
      ]);
      
      const { data: user } = userRes;
      
      // Parse visited_locations if it's a JSON string
      let visitedLocations = [];
      if (user.visited_locations) {
        if (Array.isArray(user.visited_locations)) {
          visitedLocations = user.visited_locations;
        } else if (typeof user.visited_locations === 'string') {
          try {
            visitedLocations = JSON.parse(user.visited_locations);
          } catch (e) {
            console.error("Could not parse visited_locations:", user.visited_locations, e);
            visitedLocations = [];
          }
        }
      }
      
      // Provide defaults for all missing fields
      const completeUser = {
        ...user,
        character_name: user.character_name || user.full_name || 'Adventurer',
        character_class: user.character_class || 'Fighter',
        level: user.level || 1, // Will be overridden by calculateLevel later
        coins: user.coins ?? 0,
        total_steps: user.total_steps || 0,
        daily_steps: user.daily_steps || 0,
        visited_locations: visitedLocations,
        class_changes_count: user.class_changes_count || 0,
        class_change_cost: user.class_change_cost || 500
      };

      console.log("Character Page - User Stats Received:", completeUser);
      console.log("Visited locations count:", completeUser.visited_locations.length);
      
      setUserStats(completeUser);
      
      // NEW: Get equipped items and their bonuses
      const equipped = (inventoryRes.data || []).filter(item => item.is_equipped);
      setEquippedItems(equipped);
      
      setEditData({
        character_name: completeUser.character_name,
        character_class: completeUser.character_class
      });
    } catch (error) {
      console.error("Error loading user data:", error);
      // Fallback user data
      const fallbackUser = {
        full_name: 'Adventurer',
        character_name: 'Adventurer',
        character_class: 'Fighter',
        level: 1,
        coins: 0,
        total_steps: 0,
        daily_steps: 0,
        visited_locations: [],
        class_changes_count: 0,
        class_change_cost: 500
      };
      setUserStats(fallbackUser);
      setEquippedItems([]); // Ensure equipped items are reset on fallback
      setEditData({
        character_name: fallbackUser.character_name,
        character_class: fallbackUser.character_class
      });
    }
    setIsLoading(false);
  };

  const handleSave = async () => {
    // Update local state immediately
    const updatedUser = {
      ...userStats,
      character_name: editData.character_name,
      character_class: editData.character_class
    };

    // If changing class, handle the cost calculation
    const isChangingClass = editData.character_class !== userStats.character_class;
    if (isChangingClass) {
      const changesCount = userStats.class_changes_count || 0;
      const cost = changesCount === 0 ? 0 : (userStats.class_change_cost || 500);
      
      if ((userStats.coins ?? 0) < cost) {
        alert(`You need ${cost} gold to change your class. You only have ${userStats.coins ?? 0}.`);
        setEditData({ ...editData, character_class: userStats.character_class });
        return;
      }

      updatedUser.coins = (userStats.coins ?? 0) - cost;
      updatedUser.class_changes_count = changesCount + 1;
      updatedUser.class_change_cost = Math.max(cost * 2, 500);
    }

    // Update local state first
    setUserStats(updatedUser);
    setIsEditing(false);

    // Try to save to backend but don't fail the UI if it doesn't work
    try {
      const dataToUpdate = {
        character_name: editData.character_name,
        character_class: editData.character_class
      };

      if (isChangingClass) {
        dataToUpdate.coins = updatedUser.coins;
        dataToUpdate.class_changes_count = updatedUser.class_changes_count;
        dataToUpdate.class_change_cost = updatedUser.class_change_cost;
      }

      await updateUserData(dataToUpdate);
    } catch (error) {
      console.error("Could not save character data to backend:", error);
      alert("Character changes saved locally but could not sync to server. Your changes will be preserved during this session.");
    }
  };

  const getClassData = (className) => {
    return CHARACTER_CLASSES.find(c => c.name === className) || CHARACTER_CLASSES[0];
  };

  // NEW: Calculate total equipment bonuses
  const calculateEquipmentBonuses = () => {
    const bonuses = {
      strength: 0,
      dexterity: 0,
      constitution: 0,
      intelligence: 0,
      wisdom: 0,
      charisma: 0,
      coin_bonus_percentage: 0 // daily_steps_bonus removed
    };

    equippedItems.forEach(item => {
      let statBonuses = null;
      if (item.stat_bonuses) {
        if (typeof item.stat_bonuses === 'object') {
          statBonuses = item.stat_bonuses;
        } else if (typeof item.stat_bonuses === 'string') {
          try {
            statBonuses = JSON.parse(item.stat_bonuses.replace(/'/g, '"'));
          } catch (e) {
            console.error("Could not parse stat_bonuses:", item.stat_bonuses, e);
          }
        }
      }

      if (statBonuses) {
        Object.keys(bonuses).forEach(stat => {
          if (statBonuses[stat] !== undefined && statBonuses[stat] !== null) { // Check for defined and non-null
            bonuses[stat] += Number(statBonuses[stat]) || 0; // Ensure it's a number
          }
        });
      }
    });

    return bonuses;
  };

  if (isLoading || !userStats) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-stone-900 to-amber-900 flex items-center justify-center">
        <div className="text-amber-100 text-lg">Loading character...</div>
      </div>
    );
  }

  // Use nullish coalescing (??) for safer data access
  const classData = getClassData(userStats?.character_class ?? 'Fighter');
  const ClassIcon = classData.icon;
  
  // NEW: Level calculation based on total steps
  const level = calculateLevel(userStats?.total_steps || 0);
  
  // Recalculate experience to next level based on new level logic
  const experienceToNext = level * 5000;
  
  // Calculate total steps used to reach current level
  let totalStepsUsed = 0;
  for (let i = 1; i < level; i++) {
    totalStepsUsed += i * 5000;
  }
  const currentExp = (userStats?.total_steps || 0) - totalStepsUsed;
  const expProgress = (currentExp / experienceToNext) * 100;
  
  const classChangesCount = userStats?.class_changes_count ?? 0;
  const currentClassChangeCost = classChangesCount === 0 ? 0 : (userStats.class_change_cost ?? 500);

  // NEW: Get equipment bonuses
  const equipmentBonuses = calculateEquipmentBonuses();

  // Calculate stats based on character progress + equipment
  const getStatValue = (baseStat, statName) => { // Added statName parameter
    const levelBonus = Math.floor(level / 2);
    const equipmentBonus = equipmentBonuses[statName] || 0;
    return baseStat + levelBonus + equipmentBonus;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-900 to-amber-900 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-amber-100 mb-2">
            Character Sheet
          </h1>
          <p className="text-amber-300/70">
            Manage your adventurer's details and view your progression
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Character Info */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="fantasy-border bg-gradient-to-br from-stone-800/90 to-amber-900/30 backdrop-blur-sm">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-amber-100">Character Information</CardTitle>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsEditing(!isEditing)}
                  className="border-amber-600/30 text-amber-300 hover:bg-amber-700/20"
                >
                  {isEditing ? <Save className="w-4 h-4 mr-2" /> : <Edit className="w-4 h-4 mr-2" />}
                  {isEditing ? "Save" : "Edit"}
                </Button>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center gap-6">
                  <div className={`w-20 h-20 rounded-full bg-gradient-to-br from-amber-500 to-yellow-600 flex items-center justify-center gold-glow`}>
                    <ClassIcon className={`w-10 h-10 ${classData.color}`} />
                  </div>
                  <div className="flex-1 space-y-4">
                    {isEditing ? (
                      <>
                        <div>
                          <Label htmlFor="character_name" className="text-amber-200">Character Name</Label>
                          <Input
                            id="character_name"
                            value={editData.character_name || ''}
                            onChange={(e) => setEditData({...editData, character_name: e.target.value})}
                            className="bg-stone-700/50 border-amber-600/30 text-amber-100"
                          />
                        </div>
                        <div>
                          <Label htmlFor="character_class" className="text-amber-200">Class</Label>
                          <Select
                            value={editData.character_class || 'Fighter'}
                            onValueChange={(value) => setEditData({...editData, character_class: value})}
                          >
                            <SelectTrigger className="bg-stone-700/50 border-amber-600/30 text-amber-100">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {CHARACTER_CLASSES.map((cls) => (
                                <SelectItem key={cls.name} value={cls.name}>
                                  <div className="flex items-center gap-2">
                                    <cls.icon className={`w-4 h-4 ${cls.color}`} />
                                    {cls.name}
                                 </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <div className="mt-2 text-xs text-amber-300/70 flex items-center gap-2 p-2 bg-stone-700/30 rounded-md">
                            <Info className="w-4 h-4 text-blue-400" />
                            <div>
                              <span>Cost to change: </span>
                              <span className="font-bold text-amber-200">{currentClassChangeCost} Gold</span>.
                              {currentClassChangeCost === 0 && <span> Your first change is free!</span>}
                            </div>
                          </div>
                        </div>
                      </>
                    ) : (
                      <>
                        <div>
                          <h2 className="text-2xl font-bold text-amber-100">
                            {userStats?.character_name ?? userStats?.full_name ?? "Unnamed Hero"}
                          </h2>
                          <p className="text-amber-300/70">
                            Level {level} {userStats?.character_class ?? "Fighter"}
                          </p>
                        </div>
                      </>
                    )}
                  </div>
                </div>

                {isEditing && (
                  <div className="flex gap-3">
                    <Button
                      onClick={handleSave}
                      className="bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-700 hover:to-yellow-700 text-stone-900 font-bold"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save Changes
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setIsEditing(false);
                        setEditData({
                          character_name: userStats.character_name || userStats.full_name || "",
                          character_class: userStats.character_class || "Fighter"
                        });
                      }}
                      className="border-amber-600/30 text-amber-300"
                    >
                      Cancel
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Character Stats */}
            <Card className="fantasy-border bg-gradient-to-br from-blue-900/30 to-purple-900/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-amber-100">Ability Scores</CardTitle>
                {equippedItems.length > 0 && (
                  <p className="text-sm text-green-400">✨ Enhanced by equipped items</p>
                )}
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 rounded-lg bg-stone-700/30 relative">
                    <div className="text-2xl font-bold text-amber-100">{getStatValue(12, 'strength')}</div>
                    <div className="text-sm text-amber-300/70">Strength</div>
                    {equipmentBonuses.strength > 0 && (
                      <div className="text-xs text-green-400">+{equipmentBonuses.strength} equipment</div>
                    )}
                  </div>
                  <div className="text-center p-4 rounded-lg bg-stone-700/30 relative">
                    <div className="text-2xl font-bold text-amber-100">{getStatValue(14, 'dexterity')}</div>
                    <div className="text-sm text-amber-300/70">Dexterity</div>
                    {equipmentBonuses.dexterity > 0 && (
                      <div className="text-xs text-green-400">+{equipmentBonuses.dexterity} equipment</div>
                    )}
                  </div>
                  <div className="text-center p-4 rounded-lg bg-stone-700/30 relative">
                    <div className="text-2xl font-bold text-amber-100">{getStatValue(13, 'constitution')}</div>
                    <div className="text-sm text-amber-300/70">Constitution</div>
                    {equipmentBonuses.constitution > 0 && (
                      <div className="text-xs text-green-400">+{equipmentBonuses.constitution} equipment</div>
                    )}
                  </div>
                  <div className="text-center p-4 rounded-lg bg-stone-700/30 relative">
                    <div className="text-2xl font-bold text-amber-100">{getStatValue(11, 'intelligence')}</div>
                    <div className="text-sm text-amber-300/70">Intelligence</div>
                    {equipmentBonuses.intelligence > 0 && (
                      <div className="text-xs text-green-400">+{equipmentBonuses.intelligence} equipment</div>
                    )}
                  </div>
                  <div className="text-center p-4 rounded-lg bg-stone-700/30 relative">
                    <div className="text-2xl font-bold text-amber-100">{getStatValue(15, 'wisdom')}</div>
                    <div className="text-sm text-amber-300/70">Wisdom</div>
                    {equipmentBonuses.wisdom > 0 && (
                      <div className="text-xs text-green-400">+{equipmentBonuses.wisdom} equipment</div>
                    )}
                  </div>
                  <div className="text-center p-4 rounded-lg bg-stone-700/30 relative">
                    <div className="text-2xl font-bold text-amber-100">{getStatValue(10, 'charisma')}</div>
                    <div className="text-sm text-amber-300/70">Charisma</div>
                    {equipmentBonuses.charisma > 0 && (
                      <div className="text-xs text-green-400">+{equipmentBonuses.charisma} equipment</div>
                    )}
                  </div>
                </div>

                {/* Equipment Bonuses Summary */}
                {equipmentBonuses.coin_bonus_percentage > 0 && (
                  <div className="mt-6 p-4 rounded-lg bg-amber-600/20 border border-amber-600/30">
                    <h4 className="text-amber-100 font-medium mb-2">Special Equipment Bonuses:</h4>
                    <div className="space-y-1 text-sm">
                      <div className="text-yellow-400">💰 +{equipmentBonuses.coin_bonus_percentage}% coin rewards</div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Progress & Stats */}
          <div className="space-y-6">
            <Card className="fantasy-border bg-gradient-to-br from-green-900/30 to-emerald-900/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-amber-100">Progress</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-amber-100">
                    Level {level}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-amber-200">
                    <span>Experience</span>
                    <span>{currentExp}/{experienceToNext}</span>
                  </div>
                  <Progress 
                    value={expProgress} 
                    className="h-3 bg-stone-700"
                  />
                </div>

                <div className="flex items-center justify-center gap-2 p-3 rounded-lg bg-amber-600/20">
                  <Coins className="w-5 h-5 text-amber-400" />
                  <span className="text-lg font-bold text-amber-100">
                    {userStats?.coins ?? 0} Gold
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
