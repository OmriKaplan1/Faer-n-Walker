
import React, { useState, useEffect } from "react";
import { 
  listEquipment,
  getUserData,
  updateUserData,
  deleteUserEquipment,
  updateUserEquipment,
  getInventory
} from "@/api/functions/all"; 
import { createUserEquipment } from "@/api/functions"; // Added this import
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Coins, ShoppingCart, Repeat, Info } from "lucide-react";
import ShopItem from "../components/shop/ShopItem";
import SellItem from "../components/shop/SellItem";
import InfoModal from "../components/shared/InfoModal";
import { AnimatePresence } from "framer-motion";

export default function Shop() {
  const [equipment, setEquipment] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [userStats, setUserStats] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [notification, setNotification] = useState({ isOpen: false, title: '', message: '', icon: null });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [equipmentRes, inventoryRes, userRes] = await Promise.all([
        listEquipment(),
        getInventory(),
        getUserData()
      ]);
      
      setEquipment(equipmentRes.data);
      setInventory(inventoryRes.data);
      setUserStats(userRes.data);
    } catch (error) {
      console.error("Error loading shop data:", error);
    }
    setIsLoading(false);
  };

  const handlePurchase = async (item) => {
    if (!userStats || userStats.coins < item.price) { 
      setNotification({
        isOpen: true,
        title: "Insufficient Funds",
        message: `You need ${item.price} gold to purchase ${item.name}. You only have ${userStats?.coins || 0} gold.`,
        icon: <Coins className="w-8 h-8 text-red-400" />
      });
      return;
    }

    try {
      // Step 1: Deduct coins from user
      const { data: updatedUser } = await updateUserData({
        coins: userStats.coins - item.price
      });

      // Step 2: Add/increment item in inventory
      const purchaseResult = await createUserEquipment({
        equipment_id: item.id,
      });

      console.log("Purchase result:", purchaseResult);

      // Step 3: Update UI and show success message
      setUserStats(updatedUser);
      
      setNotification({
        isOpen: true,
        title: "Purchase Successful!",
        message: `You bought ${item.name} for ${item.price} gold. It has been added to your inventory.`,
        icon: <ShoppingCart className="w-8 h-8 text-green-400" />
      });

      // Step 4: Reload data to ensure consistency
      await loadData();
      
    } catch (error) {
      console.error("Error purchasing item:", error);
      setNotification({
        isOpen: true,
        title: "Purchase Failed",
        message: "There was an error processing your purchase. Please try again.",
        icon: <ShoppingCart className="w-8 h-8 text-red-400" />
      });
    }
  };

  const handleSell = async (item) => {
    if (!userStats) { 
      console.warn("User stats not loaded.");
      return;
    }

    try {
      const { data: updatedUser } = await updateUserData({
        coins: userStats.coins + item.sell_price
      });

      if (item.quantity > 1) {
        await updateUserEquipment({
          id: item.user_equipment_id,
          data: { quantity: item.quantity - 1 }
        });
      } else {
        await deleteUserEquipment({ id: item.user_equipment_id });
      }

      setUserStats(updatedUser);
      
      setNotification({
        isOpen: true,
        title: "Item Sold!",
        message: `You sold ${item.name} for ${item.sell_price} gold.`,
        icon: <Coins className="w-8 h-8 text-green-400" />
      });

      // Full reload for consistency
      await loadData();
      
    } catch (error) {
      console.error("Error selling item:", error);
      setNotification({
        isOpen: true,
        title: "Sale Failed",
        message: "There was an error selling your item. Please try again.",
        icon: <Repeat className="w-8 h-8 text-red-400" />
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-stone-900 to-amber-900 flex items-center justify-center">
        <div className="text-amber-100 text-lg">Loading shop...</div>
      </div>
    );
  }
  
  const userInventoryCount = (itemId) => {
    const userItem = inventory.find(invItem => invItem.equipment_id === itemId);
    return userItem?.quantity || 0;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-900 to-amber-900 p-2 sm:p-4 md:p-8 overflow-x-hidden">
      <div className="max-w-full mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 md:mb-8 gap-4">
          <div className="min-w-0 flex-1">
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-amber-100 mb-2 break-words">
              Adventurer's Emporium
            </h1>
            <p className="text-amber-300/70 text-sm sm:text-base">
              Gear up for your adventures across Faerûn
            </p>
          </div>
          <Card className="fantasy-border bg-gradient-to-br from-amber-900/30 to-yellow-900/30 backdrop-blur-sm flex-shrink-0">
            <CardContent className="p-3 sm:p-4 flex items-center gap-2">
              <Coins className="w-5 h-5 sm:w-6 sm:h-6 text-amber-400" />
              <span className="text-lg sm:text-2xl font-bold text-amber-100">
                {userStats?.coins || 0}
              </span>
              <span className="text-amber-300/70 text-sm sm:text-base">Gold</span>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="buy" className="space-y-4 md:space-y-6">
          <TabsList className="bg-stone-800/50 p-1">
            <TabsTrigger value="buy" className="data-[state=active]:bg-amber-600">
              <ShoppingCart className="w-4 h-4 mr-2" /> Buy
            </TabsTrigger>
            <TabsTrigger value="sell" className="data-[state=active]:bg-amber-600">
              <Repeat className="w-4 h-4 mr-2" /> Sell
            </TabsTrigger>
          </TabsList>

          <TabsContent value="buy">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
              {equipment.map((item) => (
                <ShopItem
                  key={item.id}
                  item={item}
                  userCoins={userStats.coins}
                  onPurchase={handlePurchase}
                  userOwns={userInventoryCount(item.id)}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="sell">
            {inventory.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
                {inventory.map((item) => (
                  <SellItem
                    key={item.user_equipment_id}
                    item={item}
                    onSell={handleSell}
                  />
                ))}
              </div>
            ) : (
              <Card className="fantasy-border bg-stone-800/80 p-8 text-center">
                <Info className="w-12 h-12 mx-auto text-amber-400 mb-4" />
                <h3 className="text-xl font-bold text-amber-100">Your pack is empty!</h3>
                <p className="text-amber-300/70">You have no items to sell. Visit the 'Buy' tab to purchase equipment.</p>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Success/Error Notification Modal */}
      <AnimatePresence>
        {notification.isOpen && (
          <InfoModal
            title={notification.title}
            message={notification.message}
            icon={notification.icon}
            onClose={() => setNotification({ isOpen: false, title: '', message: '', icon: null })}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
