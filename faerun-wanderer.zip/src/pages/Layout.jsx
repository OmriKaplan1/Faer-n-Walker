
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { GpsProvider } from '@/components/GpsProvider';
import { Menu, X } from 'lucide-react';

export default function Layout({ children, currentPageName }) {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [sidebarOpen, setSidebarOpen] = useState(false);

    useEffect(() => {
        User.me()
            .then(setUser)
            .catch(() => setUser(null))
            .finally(() => setLoading(false));
    }, []);

    return (
        <GpsProvider>
            <style>{`
                :root {
                    --background: 20 14.3% 4.1%;
                    --foreground: 60 9.1% 97.8%;
                    --card: 20 14.3% 4.1%;
                    --card-foreground: 60 9.1% 97.8%;
                    --popover: 20 14.3% 4.1%;
                    --popover-foreground: 60 9.1% 97.8%;
                    --primary: 47.9 95.8% 53.1%;
                    --primary-foreground: 26 83.3% 14.1%;
                    --secondary: 12 6.5% 15.1%;
                    --secondary-foreground: 60 9.1% 97.8%;
                    --muted: 12 6.5% 15.1%;
                    --muted-foreground: 24 5.4% 63.9%;
                    --accent: 12 6.5% 15.1%;
                    --accent-foreground: 60 9.1% 97.8%;
                    --destructive: 0 84.2% 60.2%;
                    --destructive-foreground: 60 9.1% 97.8%;
                    --border: 12 6.5% 15.1%;
                    --input: 12 6.5% 15.1%;
                    --ring: 47.9 95.8% 53.1%;
                    --radius: 0.5rem;
                }
                body {
                    background-color: hsl(var(--background));
                    color: hsl(var(--foreground));
                    font-family: 'Merriweather', serif;
                }
                .fantasy-border {
                    border: 2px solid;
                    border-image: linear-gradient(to bottom right, #b48b59, #8a6538) 1;
                    box-shadow: 0 0 15px rgba(255, 193, 7, 0.2);
                }
                .fantasy-button {
                    background: linear-gradient(145deg, #a87b4a, #8a6538);
                    border: 1px solid #c8a379;
                    color: #f0e6d2;
                    padding: 10px 20px;
                    border-radius: 5px;
                    font-weight: bold;
                    text-shadow: 1px 1px 2px #000;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.5);
                    transition: all 0.2s ease-in-out;
                }
                .fantasy-button:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 4px 8px rgba(0,0,0,0.6);
                }
                .leaflet-popup-content-wrapper,
                .leaflet-popup-tip {
                    background: transparent !important;
                    color: hsl(var(--foreground));
                    box-shadow: none !important;
                }
                .leaflet-popup-content {
                    margin: 0 !important;
                }
                .leaflet-container a.leaflet-popup-close-button {
                    color: #e5cdb3 !important;
                    text-shadow: 0 0 5px black;
                    padding: 8px 8px 0 0 !important;
                }
                .leaflet-container a.leaflet-popup-close-button:hover {
                    color: #ffffff !important;
                }
            `}</style>
            <div className="min-h-screen flex w-full bg-gradient-to-br from-stone-900 via-stone-800 to-amber-900/50 text-amber-100 font-sans">
                {/* Mobile menu button */}
                <button
                    onClick={() => setSidebarOpen(!sidebarOpen)}
                    className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-stone-800/90 rounded-lg border border-amber-800/30"
                >
                    {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                </button>

                {/* Sidebar */}
                <nav className={`
                    fixed lg:static inset-y-0 left-0 z-40 w-64 
                    bg-stone-900/80 backdrop-blur-sm border-r border-amber-800/30 p-4 space-y-2
                    transform transition-transform duration-300 ease-in-out
                    ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
                `}>
                    <div className="mb-8 mt-12 lg:mt-0">
                        <h1 className="text-2xl font-bold text-amber-100 mb-2">Faerûn Wanderer</h1>
                        <p className="text-xs text-amber-300/70">Your D&D Adventure Companion</p>
                    </div>
                    
                    <Link 
                        to={createPageUrl("Dashboard")} 
                        className="block p-3 rounded-lg hover:bg-amber-800/20 transition-colors text-amber-100"
                        onClick={() => setSidebarOpen(false)}
                    >
                        🏠 Dashboard
                    </Link>
                    <Link 
                        to={createPageUrl("Map")} 
                        className="block p-3 rounded-lg hover:bg-amber-800/20 transition-colors text-amber-100"
                        onClick={() => setSidebarOpen(false)}
                    >
                        🗺️ Map
                    </Link>
                    <Link 
                        to={createPageUrl("Character")} 
                        className="block p-3 rounded-lg hover:bg-amber-800/20 transition-colors text-amber-100"
                        onClick={() => setSidebarOpen(false)}
                    >
                        ⚔️ Character
                    </Link>
                    <Link 
                        to={createPageUrl("Inventory")} 
                        className="block p-3 rounded-lg hover:bg-amber-800/20 transition-colors text-amber-100"
                        onClick={() => setSidebarOpen(false)}
                    >
                        🎒 Inventory
                    </Link>
                    <Link 
                        to={createPageUrl("Shop")} 
                        className="block p-3 rounded-lg hover:bg-amber-800/20 transition-colors text-amber-100"
                        onClick={() => setSidebarOpen(false)}
                    >
                        🛍️ Shop
                    </Link>
                    <Link 
                        to={createPageUrl("Compendium")} 
                        className="block p-3 rounded-lg hover:bg-amber-800/20 transition-colors text-amber-100"
                        onClick={() => setSidebarOpen(false)}
                    >
                        📖 Compendium
                    </Link>
                    <Link 
                        to={createPageUrl("Achievements")} 
                        className="block p-3 rounded-lg hover:bg-amber-800/20 transition-colors text-amber-100"
                        onClick={() => setSidebarOpen(false)}
                    >
                        🏆 Achievements
                    </Link>
                    
                    <div className="pt-4 border-t border-amber-800/30">
                        <button 
                            onClick={() => User.logout()} 
                            className="w-full text-left p-3 rounded-lg hover:bg-red-800/20 transition-colors text-amber-300/70 hover:text-red-300"
                        >
                            🚪 Logout
                        </button>
                    </div>
                </nav>

                {/* Mobile overlay */}
                {sidebarOpen && (
                    <div 
                        className="lg:hidden fixed inset-0 bg-black/50 z-30" 
                        onClick={() => setSidebarOpen(false)}
                    />
                )}
                
                <main className="flex-1 overflow-y-auto lg:ml-0">
                    {children}
                </main>
            </div>
        </GpsProvider>
    );
}
