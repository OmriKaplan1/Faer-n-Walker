
import React, { useState, useEffect, useRef } from "react";
import { getUserData } from "@/api/functions";
import { updateUserData } from "@/api/functions";
import StepCounter from "../components/dashboard/StepCounter";
import CharacterStatus from "../components/dashboard/CharacterStatus";
import DailyQuests from "../components/dashboard/DailyQuests";

// Function to check if it's a new day in Israel timezone
const isNewDayInIsrael = (lastDate) => {
  if (!lastDate) return true;
  
  const israelTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Jerusalem"});
  const today = new Date(israelTime).toISOString().split('T')[0];
  return lastDate !== today;
};

// Function to get current date in Israel timezone
const getIsraelDate = () => {
  const israelTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Jerusalem"});
  return new Date(israelTime).toISOString().split('T')[0];
};

// Function to get current time in Israel timezone
const getIsraeliTime = () => {
  return new Date(new Date().toLocaleString("en-US", {timeZone: "Asia/Jerusalem"}));
};

// Function to check if it's currently before noon in Israel
const isBeforeNoonInIsrael = () => {
  const israelTime = getIsraeliTime();
  return israelTime.getHours() < 12;
};

// Define quests here to be accessible for reward logic
const DAILY_QUESTS = [
    { id: 1, title: "Morning Patrol", description: "Take 2,500 steps before noon", target: 2500, reward: 50 },
    { id: 2, title: "Explorer's Journey", description: "Reach your daily step goal", target: 10000, reward: 100 },
    { id: 3, title: "Milestone Walker", description: "Reach your next step milestone", target: 1000, reward: 25 },
];

// NEW: Progressive level calculation - Level 1 needs 5000 steps, each subsequent level needs 5000 more
const calculateLevel = (totalSteps) => {
  let level = 1;
  let stepsUsed = 0;
  
  while (stepsUsed + (level * 5000) <= totalSteps) {
    stepsUsed += level * 5000;
    level++;
  }
  
  return level;
};

export default function Dashboard() {
  const [userStats, setUserStats] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const previousStats = useRef(null);

  useEffect(() => {
    // Add a small delay to prevent immediate multiple calls
    const timer = setTimeout(() => {
      loadInitialData();
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);

  const loadInitialData = async () => {
    try {
      // Load user data first
      const userRes = await getUserData();
      
      // Process user data
      let visitedLocations = [];
      if (userRes.data.visited_locations && typeof userRes.data.visited_locations === 'string') {
          try {
            visitedLocations = JSON.parse(userRes.data.visited_locations);
          } catch (e) {
            console.error("Could not parse visited_locations:", userRes.data.visited_locations, e);
            visitedLocations = [];
          }
      } else if (Array.isArray(userRes.data.visited_locations)) {
          visitedLocations = userRes.data.visited_locations;
      }
      
      const totalSteps = userRes.data.total_steps || 0;
      const level = calculateLevel(totalSteps);
      
      const processedStats = {
        ...userRes.data,
        character_name: userRes.data.character_name || userRes.data.full_name || 'Adventurer',
        character_class: userRes.data.character_class || 'Fighter',
        level: level,
        coins: userRes.data.coins ?? 0,
        total_steps: totalSteps,
        daily_steps: isNewDayInIsrael(userRes.data.last_step_date) ? 0 : (userRes.data.daily_steps || 0),
        visited_locations: visitedLocations,
        last_step_date: userRes.data.last_step_date || null
      };

      setUserStats(processedStats);
      
      // Reset daily steps if new day
      if (isNewDayInIsrael(userRes.data.last_step_date) && userRes.data.daily_steps > 0) {
        await updateUserData({
          daily_steps: 0,
          last_step_date: getIsraelDate()
        });
        
        if (window.sessionQuestRewards) {
          window.sessionQuestRewards.clear();
        }
      }
      
    } catch (error) {
      console.error("Error loading initial data:", error);
    }
    setIsLoading(false);
  };

  // Process rewards when user stats change
  useEffect(() => {
    if (!userStats || !previousStats.current) {
      return;
    }

    if (!window.sessionQuestRewards) {
        window.sessionQuestRewards = new Set();
    }

    const processRewards = async () => {
      let coinReward = 0;
      let updates = {};

      const oldUser = previousStats.current;
      const newUser = userStats;

      // 1. Check for Level-Ups with new progressive requirements
      const oldLevel = calculateLevel(oldUser.total_steps || 0);
      const newLevel = calculateLevel(newUser.total_steps || 0);

      if (newLevel > oldLevel) {
        const levelsGained = newLevel - oldLevel;
        coinReward += levelsGained * 100;
        updates.level = newLevel;
        console.log(`✨ Leveled up to ${newLevel}! Gained ${levelsGained * 100} gold.`);
      }

      // 2. Check for Daily Quest Completions (only if same day)
      // Rewards are only processed if the day hasn't changed.
      // If a new day, daily_steps are reset and sessionQuestRewards cleared, preventing re-rewards.
      if (!isNewDayInIsrael(oldUser.last_step_date)) {
        // FIX: Morning Patrol (ID 1) - Can ONLY be completed before noon in Israeli time
        const morningPatrolQuest = DAILY_QUESTS.find(q => q.id === 1);
        const wasCompletedMorning = (oldUser.daily_steps || 0) >= morningPatrolQuest.target;
        const isNowCompleteMorning = (newUser.daily_steps || 0) >= morningPatrolQuest.target;
        
        // CRITICAL FIX: Morning patrol can only be completed if it's currently before noon
        if (isNowCompleteMorning && !wasCompletedMorning && !window.sessionQuestRewards.has(1)) {
          const isCurrentlyBeforeNoon = isBeforeNoonInIsrael();
          console.log(`🕐 Morning Patrol check: Currently before noon in Israel? ${isCurrentlyBeforeNoon} (${new Date().toLocaleString("en-US", {timeZone: "Asia/Jerusalem"})})`);
          
          if (isCurrentlyBeforeNoon) {
            coinReward += morningPatrolQuest.reward;
            window.sessionQuestRewards.add(1);
            console.log(`✅ Quest "${morningPatrolQuest.title}" completed before noon! Gained ${morningPatrolQuest.reward} gold.`);
          } else {
            console.log(`❌ Quest "${morningPatrolQuest.title}" cannot be completed after noon (Israeli time).`);
          }
        }

        // Explorer's Journey (ID 2) - Daily step goal
        const explorerQuest = DAILY_QUESTS.find(q => q.id === 2);
        const wasCompletedExplorer = (oldUser.daily_steps || 0) >= explorerQuest.target;
        const isNowCompleteExplorer = (newUser.daily_steps || 0) >= explorerQuest.target;

        if (isNowCompleteExplorer && !wasCompletedExplorer && !window.sessionQuestRewards.has(2)) {
            coinReward += explorerQuest.reward;
            window.sessionQuestRewards.add(2);
            console.log(`✅ Quest "${explorerQuest.title}" completed! Gained ${explorerQuest.reward} gold.`);
        }

        // FIXED: Milestone Walker (ID 3) - Step milestones
        const milestoneQuest = DAILY_QUESTS.find(q => q.id === 3);
        const oldTotalSteps = oldUser.total_steps || 0;
        const newTotalSteps = newUser.total_steps || 0;
        
        // Check if we've crossed a 1000-step milestone
        const oldMilestone = Math.floor(oldTotalSteps / 1000);
        const newMilestone = Math.floor(newTotalSteps / 1000);
        
        if (newMilestone > oldMilestone && !window.sessionQuestRewards.has(3)) {
            coinReward += milestoneQuest.reward;
            window.sessionQuestRewards.add(3);
            console.log(`✅ Quest "${milestoneQuest.title}" completed! Reached ${newMilestone * 1000} total steps! Gained ${milestoneQuest.reward} gold.`);
        }
      }

      // Clear session rewards if new day detected by current userStats date
      const today = getIsraelDate();
      if (newUser.last_step_date !== today && oldUser.last_step_date !== today) {
          window.sessionQuestRewards.clear();
      }

      // 3. Apply updates if any rewards were earned
      if (Object.keys(updates).length > 0 || coinReward > 0) {
        updates.coins = (newUser.coins || 0) + coinReward;
        
        console.log("Applying updates and rewards:", updates);
        await updateUserData(updates);
        
        await loadUserData(false);
      }
    };

    processRewards();
  }, [userStats]);

  const loadUserData = async (isInitialLoad = false) => {
    if(isInitialLoad) setIsLoading(true);
    
    try {
      const { data: user } = await getUserData();
      
      let visitedLocations = [];
      if (user.visited_locations && typeof user.visited_locations === 'string') {
          try {
            visitedLocations = JSON.parse(user.visited_locations);
          } catch (e) {
            console.error("Could not parse visited_locations:", user.visited_locations, e);
            visitedLocations = [];
          }
      } else if (Array.isArray(user.visited_locations)) {
          visitedLocations = user.visited_locations;
      }
      
      // Calculate proper level with new requirements
      const totalSteps = user.total_steps || 0;
      const level = calculateLevel(totalSteps);
      
      const processedStats = {
        ...user,
        character_name: user.character_name || user.full_name || 'Adventurer',
        character_class: user.character_class || 'Fighter',
        level: level,
        coins: user.coins ?? 0,
        total_steps: totalSteps,
        daily_steps: isNewDayInIsrael(user.last_step_date) ? 0 : (user.daily_steps || 0),
        visited_locations: visitedLocations,
        last_step_date: user.last_step_date || null
      };
      
      previousStats.current = userStats;
      setUserStats(processedStats);

    } catch (error) {
      console.error("Error loading user:", error);
    }
    setIsLoading(false);
  };

  if (isLoading || !userStats) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-stone-800 to-amber-900 flex items-center justify-center">
        <div className="text-amber-100 text-lg">Loading your adventure...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-800 to-amber-900 p-2 sm:p-4 md:p-8 overflow-x-hidden">
      <div className="max-w-full mx-auto">
        <div className="mb-6 md:mb-8 px-2">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-amber-100 mb-2 break-words">
            Welcome, {userStats?.character_name || userStats?.full_name || "Adventurer"}!
          </h1>
          <p className="text-amber-300/70 text-sm sm:text-base">
            Your journey through Faerûn continues. Every step brings new adventures!
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-4 md:gap-6">
          <div className="lg:col-span-2 min-w-0">
            <StepCounter userStats={userStats} onUpdate={() => loadUserData(false)} />
          </div>
          <div className="min-w-0">
            <CharacterStatus userStats={userStats} />
          </div>
        </div>

        <div className="mt-4 md:mt-6">
          <DailyQuests userStats={userStats} />
        </div>
      </div>
    </div>
  );
}
