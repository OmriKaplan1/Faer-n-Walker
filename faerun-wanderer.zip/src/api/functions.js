import { base44 } from './base44Client';


export const getUserData = base44.functions.getUserData;

export const updateUserData = base44.functions.updateUserData;

export const listPointsOfInterest = base44.functions.listPointsOfInterest;

export const listRandomEncounters = base44.functions.listRandomEncounters;

export const createRandomEncounter = base44.functions.createRandomEncounter;

export const deleteRandomEncounter = base44.functions.deleteRandomEncounter;

export const listMonsters = base44.functions.listMonsters;

export const listAchievements = base44.functions.listAchievements;

export const listUserAchievements = base44.functions.listUserAchievements;

export const listEquipment = base44.functions.listEquipment;

export const listUserEquipment = base44.functions.listUserEquipment;

export const updateUserEquipment = base44.functions.updateUserEquipment;

export const createUserEquipment = base44.functions.createUserEquipment;

export const deleteUserEquipment = base44.functions.deleteUserEquipment;

export const getInventory = base44.functions.getInventory;

export const equipItem = base44.functions.equipItem;

export const useItem = base44.functions.useItem;

export const unequipItem = base44.functions.unequipItem;

export const getMapKey = base44.functions.getMapKey;

export const updatePlayerLocation = base44.functions.updatePlayerLocation;

export const getNearbyEncounters = base44.functions.getNearbyEncounters;

export const getCompendium = base44.functions.getCompendium;

export const createPlayerEncounter = base44.functions.createPlayerEncounter;

export const unlockAchievement = base44.functions.unlockAchievement;

