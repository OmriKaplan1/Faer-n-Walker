import { base44 } from './base44Client';


export const Achievement = base44.entities.Achievement;

export const UserAchievement = base44.entities.UserAchievement;

export const PointOfInterest = base44.entities.PointOfInterest;

export const Equipment = base44.entities.Equipment;

export const UserEquipment = base44.entities.UserEquipment;

export const RandomEncounter = base44.entities.RandomEncounter;

export const Monster = base44.entities.Monster;



// auth sdk:
export const User = base44.auth;