import azure.functions as func
import json
import logging
import pyodbc
import os
from datetime import datetime, date

def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError(f"Type {type(obj)} not serializable")

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Get compendium function processed a request.')

    try:
        # Get user context from URL path
        user_id = req.route_params.get('userId')
        if not user_id:
            return func.HttpResponse(
                json.dumps({"error": "User ID is required in the URL path."}),
                status_code=400,
                mimetype="application/json"
            )

        # Database connection
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()

        # Query to get user's monster encounters with monster details
        query = """
            SELECT 
                pme.id,
                pme.monster_id,
                pme.encounter_result,
                pme.encounter_date,
                pme.location_latitude,
                pme.location_longitude,
                m.name,
                m.description,
                m.challenge_rating,
                m.gold_reward,
                COALESCE(
                    SUM(CASE WHEN pme2.encounter_result = 'victory' THEN 1 ELSE 0 END), 0
                ) as victories,
                COALESCE(
                    SUM(CASE WHEN pme2.encounter_result = 'fled' THEN 1 ELSE 0 END), 0
                ) as fled,
                COALESCE(
                    SUM(CASE WHEN pme2.encounter_result = 'defeat' THEN 1 ELSE 0 END), 0
                ) as defeats
            FROM PlayerMonsterEncounter pme
            INNER JOIN Monster m ON pme.monster_id = m.id
            LEFT JOIN PlayerMonsterEncounter pme2 ON pme2.monster_id = pme.monster_id AND pme2.user_id = pme.user_id
            WHERE pme.user_id = ?
            GROUP BY pme.id, pme.monster_id, pme.encounter_result, pme.encounter_date, 
                     pme.location_latitude, pme.location_longitude, m.name, m.description, 
                     m.challenge_rating, m.gold_reward
            ORDER BY pme.encounter_date DESC
        """
        
        cursor.execute(query, user_id)
        rows = cursor.fetchall()

        compendium = []
        for row in rows:
            encounter = {
                "id": row[0],
                "monster_id": row[1],
                "encounter_result": row[2],
                "encounter_date": row[3].isoformat() if row[3] else None,  # Convert datetime to string
                "location_latitude": float(row[4]) if row[4] else None,
                "location_longitude": float(row[5]) if row[5] else None,
                "name": row[6],
                "description": row[7],
                "challenge_rating": row[8],
                "gold_reward": int(row[9]) if row[9] else 0,
                "encounter_stats": {
                    "victories": int(row[10]),
                    "fled": int(row[11]),
                    "defeats": int(row[12])
                }
            }
            compendium.append(encounter)

        result = {
            "compendium": compendium
        }

        return func.HttpResponse(
            json.dumps(result, default=json_serial),  # Use custom serializer
            status_code=200,
            mimetype="application/json"
        )

    except Exception as e:
        logging.error(f"Error getting compendium: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": f"Failed to get compendium: {str(e)}"}),
            status_code=500,
            mimetype="application/json"
        )