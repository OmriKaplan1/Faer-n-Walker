import logging
import azure.functions as func
import pyodbc
import os
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Fetching all achievements')
    try:
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM Achievement')
        achievements = [dict(zip([column[0] for column in cursor.description], row)) for row in cursor.fetchall()]
        return func.HttpResponse(json.dumps(achievements), mimetype="application/json", status_code=200)
    except Exception as e:
        logging.error(str(e))
        return func.HttpResponse(json.dumps({"error": str(e)}), mimetype="application/json", status_code=500)
