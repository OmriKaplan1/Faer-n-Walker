import logging
import json
import os
import pyodbc
import uuid
import azure.functions as func

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('--- Player Location Update Request Received ---')
    
    try:
        # Get userId from the URL query parameters
        user_id = req.params.get('userId')
        
        # Get location data from the request body
        body_data = req.get_json() or {}
        latitude = body_data.get('latitude')
        longitude = body_data.get('longitude')
        accuracy = body_data.get('accuracy')
        
        if not user_id:
            logging.error("Missing userId in URL parameters")
            return func.HttpResponse(json.dumps({"success": False, "message": "Missing userId"}), mimetype="application/json", status_code=400)
        
        if None in (latitude, longitude):
            return func.HttpResponse(json.dumps({"success": False, "message": "Missing location data"}), mimetype="application/json", status_code=400)
        
        # Connect to the database
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        
        # Generate a unique ID for the location record
        location_id = str(uuid.uuid4())
        
        sql_query = '''
            INSERT INTO UserLocation (id, user_id, latitude, longitude, accuracy, timestamp) 
            VALUES (?, ?, ?, ?, ?, GETDATE())
        '''
        
        params = (location_id, user_id, latitude, longitude, accuracy)
        
        cursor.execute(sql_query, params)
        conn.commit()
        
        logging.info(f"Successfully saved location for user: {user_id}")
        return func.HttpResponse(json.dumps({"success": True, "message": "Location updated"}), mimetype="application/json", status_code=200)
        
    except Exception as e:
        logging.error(f"Error updating player location: {e}")
        return func.HttpResponse(json.dumps({"success": False, "message": str(e)}), mimetype="application/json", status_code=500)