import azure.functions as func
import pyodbc
import os
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    user_id = req.params.get('userId')
    if not user_id:
        return func.HttpResponse(json.dumps({"error": "Missing userId"}), mimetype="application/json", status_code=400)
    try:
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        cursor.execute('''
            SELECT p.monster_id, m.name,
                   MIN(p.encounter_date) AS first_encountered,
                   COUNT(*) AS total_encounters,
                   SUM(CASE WHEN p.encounter_result = 'victory' THEN 1 ELSE 0 END) AS victories,
                   SUM(CASE WHEN p.encounter_result = 'defeated' THEN 1 ELSE 0 END) AS defeats,
                   SUM(CASE WHEN p.encounter_result = 'fled' THEN 1 ELSE 0 END) AS fled
            FROM PlayerMonsterEncounter p
            JOIN Monster m ON p.monster_id = m.id
            WHERE p.user_id = ?
            GROUP BY p.monster_id, m.name
        ''', user_id)
        encountered_monsters = [dict(zip([column[0] for column in cursor.description], row)) for row in cursor.fetchall()]
        return func.HttpResponse(json.dumps({"encountered_monsters": encountered_monsters}), mimetype="application/json", status_code=200)
    except Exception as e:
        return func.HttpResponse(json.dumps({"error": str(e)}), mimetype="application/json", status_code=500)
