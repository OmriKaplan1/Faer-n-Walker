import azure.functions as func
import pyodbc
import os
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        data = req.get_json()
        combat_session_id = data.get('combat_session_id')
        if not combat_session_id:
            return func.HttpResponse(json.dumps({"success": False, "message": "Missing combat_session_id"}), mimetype="application/json", status_code=400)
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        cursor.execute('''UPDATE CombatSession SET status = 'fled' WHERE id = ?''', combat_session_id)
        conn.commit()
        # Optionally, call player-encounters/create to record the flee
        return func.HttpResponse(json.dumps({"success": True, "message": "Successfully fled from combat.", "outcome": "fled"}), mimetype="application/json", status_code=200)
    except Exception as e:
        return func.HttpResponse(json.dumps({"success": False, "message": str(e)}), mimetype="application/json", status_code=500)
