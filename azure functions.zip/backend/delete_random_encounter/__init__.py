import azure.functions as func
import pyodbc, os, json

def main(req: func.HttpRequest) -> func.HttpResponse:
    data = req.get_json()
    encounter_id = data.get("id")
    if not encounter_id:
        return func.HttpResponse("Missing encounter id", status_code=400)
    conn = pyodbc.connect(os.getenv("SQL_CONNECTION_STRING"))
    cursor = conn.cursor()
    cursor.execute("DELETE FROM RandomEncounters WHERE id = ?", encounter_id)
    conn.commit()
    return func.HttpResponse(json.dumps({"success": True, "message": "Random encounter deleted."}), mimetype="application/json")
