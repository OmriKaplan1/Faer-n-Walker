import logging
import json
import os
import pyodbc
import azure.functions as func
from datetime import datetime
import uuid

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('--- Unlock Achievement Request Received ---')
    
    try:
        # **FINAL FIX: Use userId from the request, which is the correct uniqueidentifier for the user.**
        user_id = req.params.get('userId')
        
        request_data = req.get_json() or {}
        achievement_title = request_data.get('achievement_title')
        progress = request_data.get('progress', 0)
        
        logging.info(f"Processing achievement '{achievement_title}' for user_id '{user_id}'")
        
        if not user_id or not achievement_title:
            return func.HttpResponse(
                json.dumps({"success": False, "message": "Missing userId or achievement_title from request"}),
                mimetype="application/json",
                status_code=400
            )
        
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        
        # Step 1: Look up the achievement by its title to get its SQL ID
        cursor.execute("SELECT id FROM Achievement WHERE title = ?", (achievement_title,))
        achievement_row = cursor.fetchone()
        
        if not achievement_row:
            logging.error(f"Achievement with title '{achievement_title}' not found in the database.")
            return func.HttpResponse(
                json.dumps({"success": False, "message": f"Achievement '{achievement_title}' not found"}),
                mimetype="application/json",
                status_code=404
            )
        achievement_sql_id = achievement_row[0]

        # Step 2: Check if user already has this achievement using their user_id
        # **FINAL FIX: The column name is 'user_id'.**
        cursor.execute("""
            SELECT COUNT(*) FROM UserAchievement 
            WHERE user_id = ? AND achievement_id = ?
        """, (user_id, achievement_sql_id))
        
        if cursor.fetchone()[0] > 0:
            return func.HttpResponse(
                json.dumps({"success": False, "message": "Achievement already unlocked"}),
                mimetype="application/json",
                status_code=200 
            )
        
        # Step 3: Insert the new UserAchievement record linked by user_id
        # **FINAL FIX: The column name is 'user_id'.**
        cursor.execute("""
            INSERT INTO UserAchievement (id, achievement_id, unlocked_date, progress, user_id)
            VALUES (?, ?, GETUTCDATE(), ?, ?)
        """, (str(uuid.uuid4()), achievement_sql_id, progress, user_id))
        
        # Step 4: Get coin reward and update the User table based on their id
        cursor.execute("SELECT coin_reward FROM Achievement WHERE id = ?", (achievement_sql_id,))
        coin_reward = (cursor.fetchone()[0] or 0)

        if coin_reward > 0:
            cursor.execute("""
                UPDATE [User] SET coins = ISNULL(coins, 0) + ? 
                WHERE id = ?
            """, (coin_reward, user_id))
        
        conn.commit()
        logging.info(f"Success. User '{user_id}' unlocked '{achievement_title}' and gained {coin_reward} coins.")
        
        return func.HttpResponse(
            json.dumps({
                "success": True, 
                "message": f"Achievement '{achievement_title}' unlocked! Gained {coin_reward} coins.",
                "coin_reward": coin_reward
            }),
            mimetype="application/json",
            status_code=200
        )

    except Exception as e:
        logging.error(f"Error in unlock_achievement function: {e}")
        return func.HttpResponse(
            json.dumps({"success": False, "message": str(e)}),
            mimetype="application/json",
            status_code=500
        )