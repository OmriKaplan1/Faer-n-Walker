import azure.functions as func
import json
import logging
import pyodbc
import os
from datetime import datetime

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Create random encounter function processed a request.')

    try:
        # Get user context from query parameters
        user_id = req.params.get('userId')
        
        if not user_id:
            return func.HttpResponse(
                json.dumps({"error": "User ID is required"}),
                status_code=400,
                mimetype="application/json"
            )

        # Parse request body
        req_body = req.get_json()
        latitude = req_body.get('latitude')
        longitude = req_body.get('longitude')
        encounter_type = req_body.get('encounter_type', 'monster')
        expires_at = req_body.get('expires_at')
        min_level = req_body.get('min_level', 1)
        max_level = req_body.get('max_level', 20)
        is_active = req_body.get('is_active', True)

        if not all([latitude, longitude, expires_at]):
            return func.HttpResponse(
                json.dumps({"error": "Latitude, longitude, and expires_at are required"}),
                status_code=400,
                mimetype="application/json"
            )

        # Database connection
        conn_str = os.getenv('SQL_CONNECTION_STRING')
        if not conn_str:
            raise ValueError("SQL_CONNECTION_STRING is not set in application settings.")
            
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # --- FIX: Using 'OUTPUT INSERTED.id' for reliability ---
        # This combines the INSERT and the ID retrieval into one atomic operation.
        insert_query = """
            INSERT INTO RandomEncounters
            (latitude, longitude, encounter_type, is_active, expires_at, 
             min_level, max_level, created_by_user_id)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        # Parameters for the query
        params = (latitude, longitude, encounter_type, is_active, 
                  expires_at, min_level, max_level, user_id)
        
        # Execute and immediately fetch the returned ID
        cursor.execute(insert_query, params)
        encounter_id_row = cursor.fetchone()
        
        if not encounter_id_row:
            conn.rollback() # Abort the transaction if no ID was returned
            raise ValueError("Database did not return an ID after insertion. Transaction rolled back.")
        
        encounter_id = encounter_id_row[0]
        conn.commit() # Commit the successful transaction

        # Return the created encounter
        result = {
            "id": int(encounter_id),
            "created_by_user_id": user_id,
            "latitude": latitude,
            "longitude": longitude,
            "encounter_type": encounter_type,
            "is_active": is_active,
            "expires_at": expires_at,
            "min_level": min_level,
            "max_level": max_level,
            "created_at": datetime.utcnow().isoformat()
        }

        return func.HttpResponse(
            json.dumps(result),
            status_code=201,
            mimetype="application/json"
        )

    except Exception as e:
        logging.error(f"Error creating random encounter: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": f"Failed to create random encounter: {str(e)}"}),
            status_code=500,
            mimetype="application/json"
        )