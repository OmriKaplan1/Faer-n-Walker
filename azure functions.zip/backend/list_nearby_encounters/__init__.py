import azure.functions as func
import pyodbc
import os
import json
import math
from datetime import datetime

def haversine(lat1, lon1, lat2, lon2):
    R = 6371000  # meters
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlambda/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))

def main(req: func.HttpRequest) -> func.HttpResponse:
    user_id = req.params.get('userId')
    latitude = req.params.get('latitude')
    longitude = req.params.get('longitude')
    radius = req.params.get('radius', '1000') # Default radius to 1km
    
    if not user_id or not latitude or not longitude:
        return func.HttpResponse(json.dumps({"error": "Missing required query parameters"}), mimetype="application/json", status_code=400)
    
    try:
        latitude = float(latitude)
        longitude = float(longitude)
        radius = float(radius)
        
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()

        # --- FIX: Added 'expires_at > GETUTCDATE()' to filter expired encounters at the database level ---
        query = """
            SELECT id, latitude, longitude, encounter_type, is_active, expires_at 
            FROM RandomEncounters 
            WHERE is_active = 1 AND expires_at > GETUTCDATE()
        """
        
        cursor.execute(query)
        
        encounters = []
        for row in cursor.fetchall():
            enc = dict(zip([column[0] for column in cursor.description], row))
            dist = haversine(latitude, longitude, enc['latitude'], enc['longitude'])
            
            if dist <= radius:
                enc['distance_meters'] = dist
                # Ensure expires_at is in a consistent ISO format for JavaScript
                if hasattr(enc['expires_at'], 'isoformat'):
                    enc['expires_at'] = enc['expires_at'].strftime('%Y-%m-%dT%H:%M:%S.%fZ')
                encounters.append(enc)
                
        return func.HttpResponse(json.dumps({"encounters": encounters}), mimetype="application/json", status_code=200)

    except Exception as e:
        # Log the full error for better debugging
        import traceback
        traceback.print_exc()
        return func.HttpResponse(json.dumps({"error": str(e)}), mimetype="application/json", status_code=500)