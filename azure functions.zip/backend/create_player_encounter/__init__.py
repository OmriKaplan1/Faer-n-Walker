import azure.functions as func
import json
import logging
import pyodbc
import os
from datetime import datetime

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Create player encounter function processed a request.')

    try:
        # Get user context from query parameters
        user_id = req.params.get('userId')
        if not user_id:
            return func.HttpResponse(
                json.dumps({"error": "User ID is required in query parameters."}),
                status_code=400,
                mimetype="application/json"
            )

        # Parse request body and get the ID from the payload
        req_body = req.get_json()
        encounter_id = req_body.get('id')
        monster_id = req_body.get('monster_id')
        encounter_result = req_body.get('encounter_result')
        encounter_date = req_body.get('encounter_date', datetime.utcnow().isoformat())
        location_latitude = req_body.get('location_latitude')
        location_longitude = req_body.get('location_longitude')

        if not encounter_id or not monster_id or not encounter_result:
            return func.HttpResponse(
                json.dumps({"error": "id, monster_id, and encounter_result are required."}),
                status_code=400,
                mimetype="application/json"
            )

        # Database connection
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()

        # Insert player encounter record, now including the ID
        insert_query = """
            INSERT INTO PlayerMonsterEncounter 
            (id, user_id, monster_id, encounter_result, encounter_date, location_latitude, location_longitude, created_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, GETUTCDATE())
        """
        
        cursor.execute(
            insert_query, 
            encounter_id,
            user_id, 
            monster_id, 
            encounter_result, 
            encounter_date, 
            location_latitude, 
            location_longitude
        )
        conn.commit()

        # Return success response
        result = { "id": encounter_id, "status": "created" }

        return func.HttpResponse(
            json.dumps(result),
            status_code=201,
            mimetype="application/json"
        )

    except Exception as e:
        logging.error(f"Error creating player encounter: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": f"Failed to create player encounter: {str(e)}"}),
            status_code=500,
            mimetype="application/json"
        )