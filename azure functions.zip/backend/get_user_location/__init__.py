import azure.functions as func
import pyodbc
import os
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    user_id = req.params.get('userId')
    if not user_id:
        return func.HttpResponse(json.dumps({"error": "Missing userId"}), mimetype="application/json", status_code=400)
    try:
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        cursor.execute('''SELECT latitude, longitude, timestamp FROM UserLocation WHERE user_id = ? ORDER BY timestamp DESC''', user_id)
        row = cursor.fetchone()
        if not row:
            return func.HttpResponse(json.dumps({"error": "Location not found"}), mimetype="application/json", status_code=404)
        columns = [col[0] for col in cursor.description]
        location = dict(zip(columns, row))
        return func.HttpResponse(json.dumps(location), mimetype="application/json", status_code=200)
    except Exception as e:
        return func.HttpResponse(json.dumps({"error": str(e)}), mimetype="application/json", status_code=500)
