import azure.functions as func
import pyodbc
import os
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        data = req.get_json()
        combat_session_id = data.get('combat_session_id')
        if not combat_session_id:
            return func.HttpResponse(json.dumps({"success": False, "message": "Missing combat_session_id"}), mimetype="application/json", status_code=400)
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        # Update CombatSession status
        cursor.execute('''UPDATE CombatSession SET status = 'victory' WHERE id = ?''', combat_session_id)
        # Get gold and xp earned (example: fetch from session or monster)
        gold_earned = 500
        xp_earned = 100
        # Update user's gold/xp (example: update User table)
        # cursor.execute('''UPDATE [User] SET coins = coins + ?, xp = xp + ? WHERE id = ?''', gold_earned, xp_earned, user_id)
        conn.commit()
        # Optionally, call player-encounters/create to record the victory
        return func.HttpResponse(json.dumps({"success": True, "message": "Victory achieved!", "gold_earned": gold_earned, "xp_earned": xp_earned, "outcome": "victory"}), mimetype="application/json", status_code=200)
    except Exception as e:
        return func.HttpResponse(json.dumps({"success": False, "message": str(e)}), mimetype="application/json", status_code=500)
