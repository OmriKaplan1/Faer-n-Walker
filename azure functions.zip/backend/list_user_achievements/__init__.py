import logging
import azure.functions as func
import pyodbc
import os
import json
import datetime

def main(req: func.HttpRequest) -> func.HttpResponse:
    user_id = req.params.get('userId')
    if not user_id:
        return func.HttpResponse(json.dumps({"error": "Missing user_id"}), mimetype="application/json", status_code=400)
    logging.info(f'Fetching achievements for user {user_id}')
    try:
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        cursor.execute('''SELECT a.id, a.title, a.description, ua.unlocked_date FROM Achievement a JOIN UserAchievement ua ON a.id = ua.achievement_id WHERE ua.user_id = ?''', user_id)
        columns = [column[0] for column in cursor.description]
        achievements = []
        for row in cursor.fetchall():
            achievement = dict(zip(columns, row))
            if isinstance(achievement.get('unlocked_date'), (datetime.datetime, datetime.date)):
                achievement['unlocked_date'] = achievement['unlocked_date'].isoformat()
            achievements.append(achievement)
        return func.HttpResponse(json.dumps(achievements), mimetype="application/json", status_code=200)
    except Exception as e:
        logging.error(str(e))
        return func.HttpResponse(json.dumps({"error": str(e)}), mimetype="application/json", status_code=500)
