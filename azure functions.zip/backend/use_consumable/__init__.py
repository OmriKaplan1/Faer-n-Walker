import azure.functions as func
import pyodbc
import os
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        req_body = req.get_json()
        user_equipment_id = req_body.get('userEquipmentId')
        if not user_equipment_id:
            return func.HttpResponse(json.dumps({"error": "Missing userEquipmentId"}), mimetype="application/json", status_code=400)
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        # Check if item is consumable
        cursor.execute('''SELECT e.type, ue.quantity FROM Equipment e JOIN UserEquipment ue ON ue.equipment_id = e.id WHERE ue.id = ?''', user_equipment_id)
        row = cursor.fetchone()
        if not row:
            return func.HttpResponse(json.dumps({"error": "Item not found"}), mimetype="application/json", status_code=404)
        equip_type, quantity = row
        if equip_type != 'consumable':
            return func.HttpResponse(json.dumps({"error": "Item is not consumable"}), mimetype="application/json", status_code=400)
        if quantity > 1:
            cursor.execute('''UPDATE UserEquipment SET quantity = quantity - 1 WHERE id = ?''', user_equipment_id)
        else:
            cursor.execute('''DELETE FROM UserEquipment WHERE id = ?''', user_equipment_id)
        conn.commit()
        return func.HttpResponse(json.dumps({"success": True}), mimetype="application/json", status_code=200)
    except Exception as e:
        return func.HttpResponse(json.dumps({"error": str(e)}), mimetype="application/json", status_code=500)
