import azure.functions as func
import pyodbc
import os
import json
import math

def haversine(lat1, lon1, lat2, lon2):
    R = 6371000  # meters
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlambda/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        data = req.get_json()
        encounter_id = data.get('encounter_id')
        user_latitude = data.get('user_latitude')
        user_longitude = data.get('user_longitude')
        if not encounter_id or user_latitude is None or user_longitude is None:
            return func.HttpResponse(json.dumps({"success": False, "message": "Missing required fields"}), mimetype="application/json", status_code=400)
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        cursor.execute('''SELECT id, encounter_type, latitude, longitude, monster_id FROM RandomEncounters WHERE id = ?''', encounter_id)
        row = cursor.fetchone()
        if not row:
            return func.HttpResponse(json.dumps({"success": False, "message": "Encounter not found"}), mimetype="application/json", status_code=404)
        columns = [col[0] for col in cursor.description]
        enc = dict(zip(columns, row))
        dist = haversine(float(user_latitude), float(user_longitude), enc['latitude'], enc['longitude'])
        verified_proximity = dist <= 10  # meters
        enc['verified_proximity'] = verified_proximity
        return func.HttpResponse(json.dumps({"success": True, "encounter": enc}), mimetype="application/json", status_code=200)
    except Exception as e:
        return func.HttpResponse(json.dumps({"success": False, "message": str(e)}), mimetype="application/json", status_code=500)
