import azure.functions as func
import pyodbc
import os
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        data = req.get_json()
        encounter_id = data.get('encounter_id')
        monster_id = data.get('monster_id')
        if not encounter_id or not monster_id:
            return func.HttpResponse(json.dumps({"success": False, "message": "Missing required fields"}), mimetype="application/json", status_code=400)
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        # Create CombatSession
        cursor.execute('''INSERT INTO CombatSession (encounter_id, monster_id, status) OUTPUT INSERTED.id VALUES (?, ?, 'active')''', encounter_id, monster_id)
        row = cursor.fetchone()
        combat_id = row[0] if row else None
        # Get monster details
        cursor.execute('''SELECT name, challenge_rating, description, gold_reward FROM Monster WHERE id = ?''', monster_id)
        monster_row = cursor.fetchone()
        monster = None
        if monster_row:
            monster = dict(zip([column[0] for column in cursor.description], monster_row))
            monster['image_url'] = f"https://zoosync2.blob.core.windows.net/reportphoto/{monster['name']}.jpg"
        # Example HP values
        player_hp = 100
        monster_hp = 100
        log = [f"Combat initiated with {monster['name']}!"] if monster else []
        combat_session = {
            "id": combat_id,
            "monster": monster,
            "player_hp": player_hp,
            "monster_hp": monster_hp,
            "log": log
        }
        return func.HttpResponse(json.dumps({"success": True, "combat_session": combat_session}), mimetype="application/json", status_code=201)
    except Exception as e:
        return func.HttpResponse(json.dumps({"success": False, "message": str(e)}), mimetype="application/json", status_code=500)
