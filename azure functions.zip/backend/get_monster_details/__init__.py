import azure.functions as func
import pyodbc
import os
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    monster_id = req.route_params.get('monsterId')
    if not monster_id:
        return func.HttpResponse(json.dumps({"error": "Missing monsterId"}), mimetype="application/json", status_code=400)
    try:
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        cursor.execute('''SELECT id, name, challenge_rating, description, gold_reward, min_level, max_level FROM Monster WHERE id = ?''', monster_id)
        row = cursor.fetchone()
        if not row:
            return func.HttpResponse(json.dumps({"error": "Monster not found"}), mimetype="application/json", status_code=404)
        columns = [col[0] for col in cursor.description]
        monster = dict(zip(columns, row))
        # Construct image_url
        monster['image_url'] = f"https://zoosync2.blob.core.windows.net/reportphoto/{monster['name']}.jpg"
        return func.HttpResponse(json.dumps(monster), mimetype="application/json", status_code=200)
    except Exception as e:
        return func.HttpResponse(json.dumps({"error": str(e)}), mimetype="application/json", status_code=500)
