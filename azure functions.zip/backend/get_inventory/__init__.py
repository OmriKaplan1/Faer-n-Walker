import logging
import azure.functions as func
import pyodbc
import os
import json
from datetime import datetime

# Helper function to safely convert row data, including datetimes
def create_dict_from_row(cursor, row):
    columns = [column[0] for column in cursor.description]
    row_dict = dict(zip(columns, row))
    
    # Find any datetime objects and convert them to ISO 8601 strings
    for key, value in row_dict.items():
        if isinstance(value, datetime):
            row_dict[key] = value.isoformat()
            
    return row_dict

def main(req: func.HttpRequest) -> func.HttpResponse:
    user_id = req.params.get('userId')
    
    if not user_id:
        return func.HttpResponse("Please provide a userId parameter.", status_code=400)
        
    try:
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        
        # An efficient query to get all user inventory details in one go
        # This joins UserEquipment with the main Equipment table
        sql_query = """
            SELECT 
                ue.id as user_equipment_id,
                ue.quantity,
                ue.is_equipped,
                ue.acquired_date,
                e.id as equipment_id,
                e.name,
                e.description,
                e.type,
                e.rarity,
                e.price,
                e.sell_price,
                e.stat_bonuses
            FROM 
                UserEquipment ue
            JOIN 
                Equipment e ON ue.equipment_id = e.id
            WHERE 
                ue.user_id = ?
        """
        
        cursor.execute(sql_query, user_id)
        rows = cursor.fetchall()
        
        # Convert all rows to dictionaries, ensuring dates are handled
        result = [create_dict_from_row(cursor, row) for row in rows]
        
        cursor.close()
        conn.close()
        
        return func.HttpResponse(
            json.dumps(result),
            status_code=200,
            headers={"Content-Type": "application/json"}
        )
        
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return func.HttpResponse(json.dumps({"error": str(e)}), status_code=500)