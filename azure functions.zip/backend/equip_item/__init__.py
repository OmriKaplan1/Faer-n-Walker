import logging
import azure.functions as func
import pyodbc
import os
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        req_body = req.get_json()
        user_equipment_id = req_body.get('userEquipmentId')

        if not user_equipment_id:
            return func.HttpResponse(json.dumps({"error": "Missing userEquipmentId"}), status_code=400, headers={"Content-Type": "application/json"})

        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        
        cursor.execute("UPDATE UserEquipment SET is_equipped = 1 WHERE id = ?", (user_equipment_id))
        
        if cursor.rowcount == 0:
            return func.HttpResponse(json.dumps({"error": "Item not found or no change needed."}), status_code=404, headers={"Content-Type": "application/json"})
            
        conn.commit()
        cursor.close()
        conn.close()
        
        return func.HttpResponse(json.dumps({"success": True, "message": "Item equipped."}), status_code=200, headers={"Content-Type": "application/json"})

    except Exception as e:
        logging.error(f"Error equipping item: {str(e)}")
        return func.HttpResponse(json.dumps({"error": str(e)}), status_code=500, headers={"Content-Type": "application/json"})