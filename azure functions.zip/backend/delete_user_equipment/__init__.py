import logging
import azure.functions as func
import pyodbc
import os
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Delete user equipment function processed a request.')
    
    try:
        # Get user context from query parameters
        user_id = req.params.get('userId')
        if not user_id:
            return func.HttpResponse(
                json.dumps({"error": "User ID is required in query parameters."}),
                status_code=400,
                mimetype="application/json"
            )

        # Parse request body to get the ID of the item to delete
        try:
            req_body = req.get_json()
            user_equipment_id = req_body.get('id')
        except ValueError:
            return func.HttpResponse(
                json.dumps({"error": "Invalid JSON in request body."}),
                status_code=400,
                mimetype="application/json"
            )

        if not user_equipment_id:
            return func.HttpResponse(
                json.dumps({"error": "Request body must include the 'id' of the equipment to delete."}),
                status_code=400,
                mimetype="application/json"
            )

        # Database connection
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()

        # Execute the DELETE statement
        delete_query = """
            DELETE FROM UserEquipment 
            WHERE id = ? AND user_id = ?
        """
        
        cursor.execute(delete_query, user_equipment_id, user_id)
        
        # Check if a row was actually deleted
        if cursor.rowcount == 0:
            conn.close()
            return func.HttpResponse(
                json.dumps({"error": "Equipment not found for this user or already deleted."}),
                status_code=404,
                mimetype="application/json"
            )
            
        conn.commit()
        conn.close()

        return func.HttpResponse(
            json.dumps({"success": True, "message": f"Equipment with id {user_equipment_id} has been deleted."}),
            status_code=200,
            mimetype="application/json"
        )

    except Exception as e:
        logging.error(f"Error deleting user equipment: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": f"An unexpected error occurred while deleting equipment: {str(e)}"}),
            status_code=500,
            mimetype="application/json"
        )