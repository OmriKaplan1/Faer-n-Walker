import logging
import azure.functions as func
import pyodbc
import os
import json
from datetime import datetime

def main(req: func.HttpRequest) -> func.HttpResponse:
    conn = None
    try:
        req_body = req.get_json()
        logging.info(f"📦 Received request body: {req_body}")
        
        user_id = req_body.get('user_id')
        equipment_id = req_body.get('equipment_id')
        
        if not user_id or not equipment_id:
            return func.HttpResponse("Missing required fields: user_id, equipment_id", status_code=400)
            
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        
        # STEP 1: Check if the item exists (ignore the broken id column)
        select_query = "SELECT quantity FROM UserEquipment WHERE user_id = ? AND equipment_id = ?"
        logging.info(f"🔍 Checking for existing item with query: {select_query}")
        cursor.execute(select_query, (user_id, equipment_id))
        existing_item = cursor.fetchone()
        
        if existing_item:
            current_quantity = existing_item[0]
            new_quantity = current_quantity + 1
            
            # STEP 2: Update directly using user_id and equipment_id (bypass broken id)
            update_query = "UPDATE UserEquipment SET quantity = ? WHERE user_id = ? AND equipment_id = ?"
            logging.info(f"📈 Updating quantity from {current_quantity} to {new_quantity}")
            cursor.execute(update_query, (new_quantity, user_id, equipment_id))
            
            if cursor.rowcount == 0:
                message = f"UPDATE failed - no rows affected"
                logging.error(message)
            else:
                message = f"Successfully updated item quantity to {new_quantity}"
                logging.info(message)
        else:
            logging.info("🆕 No existing item found. Creating new record.")
            acquired_date = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
            
            # Don't specify id in INSERT - let SQL Server handle it
            insert_query = """
                INSERT INTO UserEquipment (user_id, equipment_id, quantity, is_equipped, acquired_date) 
                VALUES (?, ?, ?, ?, ?)
            """
            params = (user_id, equipment_id, 1, 0, acquired_date)
            cursor.execute(insert_query, params)
            message = "Successfully created new item in inventory"

        conn.commit()
        logging.info("💾 Transaction committed successfully.")
        
        return func.HttpResponse(
            json.dumps({"success": True, "message": message}),
            status_code=200,
            headers={"Content-Type": "application/json"}
        )
        
    except Exception as e:
        logging.error(f"❌ An error occurred: {str(e)}", exc_info=True)
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)
    finally:
        if conn:
            cursor.close()
            conn.close()
            logging.info("🔌 Database connection closed.")