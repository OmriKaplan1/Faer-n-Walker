import logging
import json
import os
import pyodbc
import uuid
import azure.functions as func

def main(req: func.HttpRequest) -> func.HttpResponse:
    # --- Start of Intensive Logging ---
    logging.info('--- New Location Update Request Received ---')
    
    # Log query parameters to see what's in the URL
    try:
        params_dict = dict(req.params)
        logging.info(f"Received URL Query Parameters: {json.dumps(params_dict)}")
    except Exception as e:
        logging.warning(f"Could not log query parameters: {e}")

    # Log the request body to see what's in the JSON payload
    try:
        body_data = req.get_json()
        logging.info(f"Received Request Body: {json.dumps(body_data)}")
    except ValueError:
        body_data = {} # Handle cases with no body
        logging.warning("Request had no valid JSON body.")
    except Exception as e:
        body_data = {}
        logging.warning(f"Could not log request body: {e}")
    # --- End of Intensive Logging ---

    user_id = None
    # Try to get user_id from query parameters first (the correct way)
    if 'userId' in req.params:
        user_id = req.params.get('userId')
        logging.info(f"SUCCESS: Found userId in URL parameters: '{user_id}'")
    # Fallback: if not in URL, check the JSON body (the old way)
    elif 'userId' in body_data:
        user_id = body_data.get('userId')
        logging.warning(f"FALLBACK: Found userId in request body: '{user_id}'")

    # Get the rest of the data from the body
    latitude = body_data.get('latitude')
    longitude = body_data.get('longitude')
    accuracy = body_data.get('accuracy')

    # Now, check if user_id was found anywhere. If not, fail with a clear error.
    if not user_id:
        logging.error("CRITICAL: user_id was not found in URL parameters or request body.")
        return func.HttpResponse(
            json.dumps({"success": False, "message": "CRITICAL FAILURE: Could not find user_id in the request from any source."}),
            mimetype="application/json",
            status_code=400
        )

    try:
        # Check for required location fields in the body
        if None in (latitude, longitude):
            return func.HttpResponse(
                json.dumps({"success": False, "message": "Missing required fields in body: latitude, longitude."}),
                mimetype="application/json",
                status_code=400
            )

        # Connect to the database
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()

        location_id = str(uuid.uuid4())
        sql_query = '''
            INSERT INTO UserLocation (id, user_id, latitude, longitude, accuracy, timestamp) 
            VALUES (?, ?, ?, ?, ?, GETDATE())
        '''
        params = (location_id, user_id, latitude, longitude, accuracy)
        
        cursor.execute(sql_query, params)
        conn.commit()

        logging.info(f"Successfully inserted location for user: {user_id}")
        return func.HttpResponse(
            json.dumps({"success": True, "message": "User location updated successfully."}),
            mimetype="application/json",
            status_code=200
        )

    except Exception as e:
        # Log the specific user ID that caused the error
        logging.error(f"DATABASE ERROR for user '{user_id}': {e}")
        return func.HttpResponse(
            json.dumps({"success": False, "message": str(e)}),
            mimetype="application/json",
            status_code=500
        )