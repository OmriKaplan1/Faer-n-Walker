import azure.functions as func
import pyodbc
import os
import json
from datetime import datetime

def main(req: func.HttpRequest) -> func.HttpResponse:
    user_id = req.params.get('userId')
    
    if not user_id:
        return func.HttpResponse(json.dumps({"error": "User ID required"}), mimetype="application/json", status_code=400)
    
    try:
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        
        # Delete expired encounters for this user
        current_time = datetime.utcnow().isoformat()
        cursor.execute('''
            DELETE FROM RandomEncounters 
            WHERE expires_at <= ? 
            AND created_by_user_id = ?
        ''', (current_time, user_id))
        
        deleted_count = cursor.rowcount
        conn.commit()
        
        return func.HttpResponse(json.dumps({"deleted_count": deleted_count}), mimetype="application/json", status_code=200)
    
    except Exception as e:
        return func.HttpResponse(json.dumps({"error": str(e)}), mimetype="application/json", status_code=500)