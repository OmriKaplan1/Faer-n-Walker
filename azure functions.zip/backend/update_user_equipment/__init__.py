import logging
import azure.functions as func
import pyodbc
import os
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Update user equipment function processed a request.')
    
    try:
        # Get user context from query parameters
        user_id = req.params.get('userId')
        if not user_id:
            return func.HttpResponse(
                json.dumps({"error": "User ID is required in query parameters."}),
                status_code=400,
                mimetype="application/json"
            )

        # Parse request body
        req_body = req.get_json()
        user_equipment_id = req_body.get('id')
        data_to_update = req_body.get('data')

        if not user_equipment_id or not data_to_update or 'quantity' not in data_to_update:
            return func.HttpResponse(
                json.dumps({"error": "Request body must include 'id' and 'data' with a 'quantity' field."}),
                status_code=400,
                mimetype="application/json"
            )

        new_quantity = data_to_update.get('quantity')
        
        # Database connection
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()

        # Update the quantity for the specific UserEquipment row
        update_query = """
            UPDATE UserEquipment 
            SET quantity = ? 
            WHERE id = ? AND user_id = ?
        """
        
        cursor.execute(update_query, new_quantity, user_equipment_id, user_id)
        
        if cursor.rowcount == 0:
            conn.close()
            return func.HttpResponse(
                json.dumps({"error": "Equipment not found for this user or no changes made."}),
                status_code=404,
                mimetype="application/json"
            )
            
        conn.commit()
        conn.close()

        return func.HttpResponse(
            json.dumps({"success": True, "message": f"Quantity updated to {new_quantity} for item {user_equipment_id}"}),
            status_code=200,
            mimetype="application/json"
        )

    except Exception as e:
        logging.error(f"Error updating user equipment: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": f"An unexpected error occurred: {str(e)}"}),
            status_code=500,
            mimetype="application/json"
        )