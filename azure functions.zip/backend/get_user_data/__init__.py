import azure.functions as func
import pyodbc
import os
import json
import datetime

def main(req: func.HttpRequest) -> func.HttpResponse:
    user_id = req.params.get("userId")
    user_email = req.params.get("userEmail")
    if not user_id or not user_email:
        return func.HttpResponse("Missing userId or userEmail", status_code=400)

    try:
        conn = pyodbc.connect(os.getenv("SQL_CONNECTION_STRING"))
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM [User] WHERE id = ? AND email = ?", user_id, user_email)
        row = cursor.fetchone()
        if not row:
            today = datetime.date.today().strftime('%Y-%m-%d')
            default_data = {
                'id': user_id,
                'full_name': 'Adventurer',
                'email': user_email,
                'role': 'user',
                'character_name': 'adventurer',
                'character_class': 'fighter',
                'level': 1,
                'coins': 0,
                'total_steps': 0,
                'daily_steps': 0,
                'last_step_date': today,
                'visited_locations': json.dumps([]),
                'has_selected_class': False,
                'class_change_cost': 0,
                'class_changes_count': 0
            }
            cursor.execute('''INSERT INTO [User] (id, full_name, email, role, character_name, character_class, level, coins, total_steps, daily_steps, last_step_date, visited_locations, has_selected_class, class_change_cost, class_changes_count) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                default_data['id'], default_data['full_name'], default_data['email'], default_data['role'], default_data['character_name'], default_data['character_class'], default_data['level'], default_data['coins'], default_data['total_steps'], default_data['daily_steps'], default_data['last_step_date'], default_data['visited_locations'], default_data['has_selected_class'], default_data['class_change_cost'], default_data['class_changes_count'])
            conn.commit()
            return func.HttpResponse(json.dumps(default_data), mimetype="application/json", status_code=201)
        columns = [col[0] for col in cursor.description]
        result = dict(zip(columns, row))
        if "Visited_Locations" in result and result["Visited_Locations"]:
            result["Visited_Locations"] = json.loads(result["Visited_Locations"])
        # Convert date objects to string for JSON serialization
        for k, v in result.items():
            if isinstance(v, datetime.date):
                result[k] = v.strftime('%Y-%m-%d')
        return func.HttpResponse(json.dumps(result), mimetype="application/json", status_code=200)
    except Exception as e:
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)
