import azure.functions as func
import pyodbc, os, json

def main(req: func.HttpRequest) -> func.HttpResponse:
    conn = pyodbc.connect(os.getenv("SQL_CONNECTION_STRING"))
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Monster")
    rows = cursor.fetchall()
    columns = [col[0] for col in cursor.description]
    result = [dict(zip(columns, row)) for row in rows]
    return func.HttpResponse(json.dumps(result), mimetype="application/json")
