import logging
import azure.functions as func
import pyodbc
import os
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    user_id = req.params.get('userId')
    if not user_id:
        return func.HttpResponse("Missing user_id", status_code=400)
    logging.info(f'Fetching equipment for user {user_id}')
    try:
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        cursor.execute('''
            SELECT ue.id, ue.user_id, ue.equipment_id, ue.quantity, ue.is_equipped, ue.acquired_date,
                   e.name, e.type, e.description, e.rarity, e.price, e.sell_price, e.class_restricted, e.is_permanent, e.stat_bonuses
            FROM UserEquipment ue
            JOIN Equipment e ON ue.equipment_id = e.id
            WHERE ue.user_id = ?
        ''', user_id)
        equipment = [dict(zip([column[0] for column in cursor.description], row)) for row in cursor.fetchall()]
        return func.HttpResponse(json.dumps(equipment), mimetype="application/json", status_code=200)
    except Exception as e:
        logging.error(str(e))
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)
