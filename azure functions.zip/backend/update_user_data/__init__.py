import logging
import json
import os
import pyodbc
import azure.functions as func
from datetime import date, datetime

# Helper function to convert date/datetime objects to strings for JSON
def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError ("Type %s not serializable" % type(obj))

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('--- User Data Update Request Received ---')
    
    try:
        user_id_value = req.params.get('userId')
        user_email_value = req.params.get('userEmail')
        update_data = req.get_json() or {}
        
        logging.info(f"Attempting to update user '{user_id_value}' with data: {json.dumps(update_data)}")
        
        if not user_id_value:
            return func.HttpResponse(
                json.dumps({"success": False, "message": "Missing userId in URL parameters"}),
                mimetype="application/json",
                status_code=400
            )
        
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM [User] WHERE id = ?", (user_id_value,))
        user_exists = cursor.fetchone()[0] > 0
        
        if user_exists:
            set_clauses = []
            params = []
            allowed_columns = [
                'character_name', 'character_class', 'level', 'coins', 'total_steps', 
                'daily_steps', 'last_step_date', 'visited_locations', 'class_changes_count', 
                'class_change_cost'
            ]
            
            for key, value in update_data.items():
                if key in allowed_columns:
                    set_clauses.append(f"[{key}] = ?")
                    if isinstance(value, (list, dict)):
                        params.append(json.dumps(value))
                    else:
                        params.append(value)
            
            if set_clauses:
                params.append(user_id_value)
                sql_query = f"UPDATE [User] SET {', '.join(set_clauses)} WHERE id = ?"
                cursor.execute(sql_query, tuple(params))
        else:
            logging.info(f"User {user_id_value} not found. Creating new record.")
            cursor.execute('''
                INSERT INTO [User] ([id], [email], [character_name], [coins], [total_steps], [daily_steps], [visited_locations])
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                user_id_value, user_email_value or '', update_data.get('character_name', 'Adventurer'),
                update_data.get('coins', 100), update_data.get('total_steps', 0),
                update_data.get('daily_steps', 0), json.dumps(update_data.get('visited_locations', []))
            ))

        conn.commit()
        
        cursor.execute("SELECT * FROM [User] WHERE id = ?", (user_id_value,))
        columns = [column[0] for column in cursor.description]
        row = cursor.fetchone()
        
        if row:
            user_data = dict(zip(columns, row))
            for key, value in user_data.items():
                if isinstance(value, str) and value.startswith(('[', '{')):
                    try:
                        user_data[key] = json.loads(value)
                    except json.JSONDecodeError:
                        pass
            
            # --- FIX: Use the custom serializer to handle date objects ---
            return func.HttpResponse(json.dumps(user_data, default=json_serial), mimetype="application/json", status_code=200)
        else:
            return func.HttpResponse(json.dumps({"success": False, "message": "User not found after update."}), mimetype="application/json", status_code=404)

    except Exception as e:
        logging.error(f"Error in user data update: {e}")
        return func.HttpResponse(json.dumps({"success": False, "message": str(e)}), mimetype="application/json", status_code=500)