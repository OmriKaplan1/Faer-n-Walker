import logging
import azure.functions as func
import pyodbc
import os
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Fetching all equipment')
    try:
        conn = pyodbc.connect(os.getenv('SQL_CONNECTION_STRING'))
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM Equipment')
        equipment = []
        for row in cursor.fetchall():
            item = dict(zip([column[0] for column in cursor.description], row))
            # Ensure class_restricted is a JSON array
            if 'class_restricted' in item:
                try:
                    val = item['class_restricted']
                    if val is None or val == '':
                        item['class_restricted'] = []
                    elif isinstance(val, str):
                        item['class_restricted'] = json.loads(val)
                except Exception:
                    item['class_restricted'] = []
            equipment.append(item)
        return func.HttpResponse(json.dumps(equipment), mimetype="application/json", status_code=200)
    except Exception as e:
        logging.error(str(e))
        return func.HttpResponse(json.dumps({"error": str(e)}), mimetype="application/json", status_code=500)
